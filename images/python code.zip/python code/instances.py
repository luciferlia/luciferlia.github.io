# -*- coding: utf-8 -*-
class Animal(object):
             """docstring for Animal"""
    pass

class Runnable(object)：
    def run(self):
        print('running......')

class Flying(object):
    def fly(self):
        print('flying...')
#犬类
class Mammal(Animal):
    pass
#鸟类
class Bird(Animal):
    pass

class Dog(Mammal,Runnable):
    pass

class Bat(Mammal,Flying):
    pass
class Parrot(Bird,Flying):
    pass
class Ostrich(Bird,Runnable):
    pass                          
                          