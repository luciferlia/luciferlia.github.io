# -*- coding: utf-8 -*-
def yang(max):
   L=[1]
   yield L
   L=[]
   for i in range(1,max):
       for j in range(0,i+1):
           L.append(int(factorial(i)/(factorial(i-j)*factorial(j))))

       yield L
       L=[]
   return 'done'    
   
