# -*- coding: utf-8 -*-
def pow(x):
    return x*x*x
