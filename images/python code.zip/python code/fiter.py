# -*- coding: utf-8 -*-
def is_odd(n):
    return n%2==1

