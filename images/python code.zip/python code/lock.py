# -*- coding: utf-8 -*-
# for windowns
import time,threading
balance=0
lock=threading.Lock()
#新线程执行的代码：
def change_it(n):
	#先取后存，结果应该是0
	global balance
	balance=balance+n
	balance=balance-n
def run_thread(n):
	for i in range(1000000):
		#先获取锁
		lock.acquire()
		try:
			#改动
			#print(n)
			change_it(n)
		finally:
		    #改完一定要释放锁
		    lock.release()
t1=threading.Thread(target=run_thread,args=(5,))
t2=threading.Thread(target=run_thread,args=(8,))
t1.start()
t2.start()
t1.join()
t2.join()
print(balance)		    	

