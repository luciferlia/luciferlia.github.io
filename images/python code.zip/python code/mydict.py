# -*- coding: utf-8 -*-
# 凡是用print()来辅助查看的地方，都可以用断言(assert)来代替
class Dict(dict):
	def __init__(self,**kw):
		super().__init__(**kw)
	def __getattr__(self,key):
	    try:
	        return self[key]
	    except KeyError:
	        raise AttributeError(r"'Dict' object has no attribute '%s'"% key)
	def __setattr__(self,key,value):
	    self[key]=value            	
   