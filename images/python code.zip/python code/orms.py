# -*- coding: utf-8 -*-
# ORM object relationship mapping 对象映射关系
# 把关系数据库的一行映射为一个对象，也就是一个类对应一个表
#定义Field类，负责保存数据库表的字段名和字段类型
import logging #记录错误
class Field(object):
	def __init__(self,name,column_type):
		self.name=name
		self.column_type=column_type
#__class__获得已知对象的类,任何对象都有这个属性，__name__取得类名
	def __str__(self):
		return '<%s:%s>' % (self.__class__.__name__,self.name)
# 在Feild的基础上，进一步定义各种类型的Field
class StringField(Field):
	def __init__(self,name):
		super(StringField,self).__init__(name,'varchar(100)')

class IntegerField(Field):
	def __init__(self,name):
		super(IntegerField,self).__init__(name,'bigint')


# ModelMetaclass
class ModelMetaclass(type):
	def __new__(cls,name,bases,attrs):
		if name=='Model':
			return type.__new__(cls,name,bases,attrs)
		print('Found model:%s ' % name)
		mappings=dict()
		for k,v in attrs.items():
			if isinstance(v,Field):
				print('Found mapping: %s ==> %s' % (k,v))
				mappings[k]=v
		for k in mappings.keys():
		    attrs.pop(k)
		attrs['__mappings__']=mappings #保存属性和列的映射关系
		attrs['__table__']=name # 假设表名和类名一致
		return type.__new__(cls,name,bases,attrs)    	
# 基类
class Model(dict,metaclass=ModelMetaclass):
    def __init__(self,**kw):
        super(Model,self).__init__(**kw)
    def __getattr__(self,key):
        try:
             return self[key] 
        except KeyError:
             raise AttributeError(r"'Model' object has no attribute '%s'"% key)
    def __setattr__(self,key,value):
        self[key]=value
    def save(self):
    	fields=[]
    	params=[]
    	args=[]
    	for k,v in self.__mappings__.items():
    		fields.append(v.name)
    		params.append("?")
    		args.append(getattr(self,k,None))
    	sql='inser into %s (%s) values (%s)' % (self.__table__,','.join(fields),','.join(params))
    	print('SQL : %s' %sql)
    	print('ARGS: %s' % str(args))	


