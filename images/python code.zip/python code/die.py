# -*- coding: utf-8 -*-
d={'a':1,'b':2,'c':3,'d':4}
for x,y in d.items():
    print(x,y)
