# -*- coding: utf-8 -*-
def fib(max):
    n,a,b=0,0,1
    while n<max:
      #list写法  print(b)
        #生成器 generator写法 
        yield b
        a,b=b,a+b
        n=n+1

    return 'done'    
