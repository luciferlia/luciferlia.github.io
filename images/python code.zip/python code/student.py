# -*- coding: utf-8 -*-
class Student(object):
      	"""docstring for Student"""
      	#python内置的@property装饰器负责吧一个方法变成属性调用
      	@property
      	def get_score(self):
      		return self._score
 # 把一个getter方法变成属性，只需要加上@property，此时，@property
 # 本身又创建了另一个装饰器@score.setter,负责吧一个setter方法变成属性赋值     		
 #此时我们就拥有一个可控的属性操作
      	@score.setter	
      	def set_score(self,value):
      	    if not isinstance(value,int):
      	    	raise ValueError('score must be an integer')
      	    if value <0 or value>100:
      	        raise ValueError('score must between 0-100')
      	    self._score=value    	

