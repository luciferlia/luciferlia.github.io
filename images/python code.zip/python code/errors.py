# -*- coding: utf-8 -*-
# 凡是用print()来辅助查看的地方，都可以用断言(assert)来代替
def foo(s):
	n=int(s)
	assert n != 0,'n is zero'
	return 10/n
def main():
    foo('0')	
   