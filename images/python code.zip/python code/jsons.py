# -*- coding: utf-8 -*-
import json
class Student(object):
    def __init__(self,name,age,score):
        self.name=name
        self.age=age
        self.score=score
s=Student('廖',25,98)
data=json.dumps(s,default=lambda obj: obj.__dict__)
print(data)
redata=json.loads(data,object_hook=lambda d: Student(d['name'],d['age'],d['score']))
print(redata)        