# -*- coding: utf-8 -*-
class Student(object):
   def __init__(self,name):
        self.name=name;
   def __str__(self):
        return 'Student object name:%s' % self.name     
# __str__()返回用户看到的字符串，而__repr__()返回程序开发者看到的字符串，也就是说，__repr__()是为调试服务的。
#v解决办法是再定义一个__repr__()。但是通常__str__()和__repr__()代码都是一样的
   __repr__=__str__

class Fib(object):
   def __init__(self):
        self.a,self.b=0,1 # 初始化两个计数器

   def __iter__(self):
        return self # 实例本身就是迭代对象，故返回自己

   def __next__(self):
        self.a,self.b=self.b,self.a+self.b #计算下一个值
        if self.a>10000:# 退出循环条件
            raise StopIteration()    
        return self.a
   def __getitem__(self,n):
        # a,b=1,1
        # for x in range(n):
        #      a,b=b,a+b
        # return a  
        if isinstance(n,int):#n是索引
            a,b=1,1
            for x in range(n):
                a,b=b,a+b
            return a
        if isinstance(n,slice):#n是切片
            start=n.start
            stop=n.stop
            if start is None:
                start=0
            a,b=1,1
            L=[]
            for x in range(stop):
                if x>=start:
                     L.append(a)
                a,b=b,a+b
            return L  
   def __getattr__(self,attr):
        if attr=='age':
            return lambda:25
        raise AttributeError('object has no attribute \'%s\''  %attr)      

class Chain(object):# 利用动态的__getattr__来写一个链式的调用
      def __init__(self,path=''):
           self.path=path 
      def __getattr__(self,path):
           return Chain(' %s/%s ' % (self.path,path))
      def __str__(self):
           return self.path

      __repr__=__str__    

class Person(object):
    def __init__(self,age):
        self.age=age

    def __call__(self):
        print('your age is %s' % self.age)     
