# -*- coding: utf-8 -*-
class Hello(object):
  #共有方法
    def hello(self,name='world'):
      print('hello , %s' % name)
    #   私有方法
    def __init__(self,name):
      self.name=name

    def __str__(self):
       return 'hello my girls %s name' % self.name  