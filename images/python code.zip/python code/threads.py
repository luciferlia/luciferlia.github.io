# -*- coding: utf-8 -*-
# for windowns
from multiprocessing import Process
import os
#子进程要执行的代码
def run_proc(name):
	print('Run children process %s (%s)...' % (name,os.getpid()))
if __name__=='__main__':
   print('Parent process %s' % os.getpid())	
   p=Process(target=run_proc,args=('test',))
   print('Children process will start...')
   p.start()
   p.join()#可以等待子进程结束后再继续往下运行，通常用于进程间的同步
   print('Children process end')
