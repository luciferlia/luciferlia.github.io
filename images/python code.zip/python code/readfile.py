# readfile.py
# -*- coding: utf-8 -*-
