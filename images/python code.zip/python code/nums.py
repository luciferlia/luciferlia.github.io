# -*- coding: utf-8 -*-
def nums(*num):
   sum=0
   for n in num:
       sum = sum+n*n
   return sum    

def person(name,age,**kw):
    if 'city' in kw:
        pass
    if 'job' in kw:
        pass
    print('name:',name,'age:',age,'other:',kw)
