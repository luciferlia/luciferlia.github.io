# -*- coding: utf-8 -*-

class Animal(object):

	def run(self):
	    print('Animal is runnings...')

class Dog(Animal):
	pass

class Cat(Animal):
    def run(self):
        print('Cat is running')
    def eat(self):
    	print('Cat is eating...')
def run_twice(animal):
	animal.run()
	animal.run()
class Tortoise(Animal):
	def run(self):
		print('Tortoise is running slowly...')

class Student(object):
			"""docstring for Student"""
			__slots__=('name','age')#用tuple元组定义允许绑定的属性名称
			#def __init__(self, arg):
				#super(Student, self).__init__()
				#self.arg = arg
class Graduate(Student):
      pass						
s=Student()#创建新的实例
s.name='liao'#绑定属性'name'
s.age=25 #绑定属性'age'
# ERROR:'Student' object has no attribute 'score'
try:
   s.score=99
except AttributeError as e:
   print('AttributeError',e)

g=Graduate()
g.score=99
print('g.score=',g.score)           