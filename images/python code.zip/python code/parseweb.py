# -*- coding: utf-8 -*-
from urllib import request
from bs4 import BeautifulSoup

#path = "C:\\Users\\Administrator\\Desktop\\our_events_python.html"
url = "https://www.python.org/events/python-events/"


def crawl_page(path):
    return request.urlopen(url).read().decode("utf-8")


def parse_web(data):
    soup = BeautifulSoup(data, "html.parser")
    conference_list = soup.find('ul', attrs={'class': 'list-recent-events menu'})
    for li in conference_list.find_all("li"):
        print("meeting name:", li.find('h3', attrs={'class': 'event-title'}).getText())  # 名称
        print("time:", li.find('time').getText())
        print("address:", li.find('span', attrs={"class": "event-location"}).getText()+"\n")


if __name__ == '__main__':
    # print(crawl_page(url))
    parse_web(crawl_page(url))