<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8');
 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
	 <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>
<script src="js/echarts.js"></script>
<style>
li {
	float:left;
}
body{background-color:#F5FFFA;}
#main{
   border:4px solid #DCDCDC;
	border-radius:25px;
	
}
</style>

<script>


var form;
	layui.use(['form', 'layedit', 'laydate'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  
});

 </script>
</head>
<body>
<?php 
$search['name'] = $_GET['lab'];
?>
<span id="name" style="display:none;"><?php echo "{$search['name']}"?></span>

<div id="main" style="min-width:600px;width:80%;height:800px;margin-left:10%;margin-top:5%;"></div>
<script>
var lab=$('#name').text();
$.ajax({
	url:'show.php?lab='+lab,
	type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(result){
		var str=JSON.parse(result);
		var dataY=new Array();
	   var dataX=new Array();
		for(i=0;i<str.length;i++){
			var dataA=str[i].dev_sty;
			var dat=str[i].devsum;
			dataY.push(dataA);
			dataX.push(dat);
		}
		
var myChart=echarts.init(document.getElementById('main'));

var yMax = 15;
var dataShadow = [];

for (var i = 0; i < dataX.length; i++) {
    dataShadow.push(yMax);
}

option = {
    title: {
        text: '实验室设备使用情况',
        subtext: '点击可缩大或放小'
    },
	 toolbox: {
        show : true,
        feature : {
            dataView : {show: true, readOnly: false},
            magicType : {show: true, type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
	 tooltip: {
    },
    xAxis: {
         type: 'value',
       
		 axisTick: {
            show: true
        },
        axisLine: {
            show: true
        },
        z: 5
    },
	   grid: { // 控制图的大小，调整下面这些值就可以，
             x: 170,
             x2: 100,
             y2: 50,// y2可以控制 X轴跟Zoom控件之间的间隔，避免以为倾斜后造成 label重叠到zoom上
         },

    yAxis: {
       type: 'category',
        data:dataY,
		 axisLabel:{
                 interval:0,
                 rotate:45,
                 margin:2,
                 textStyle:{
                         color:"#000000"
                         }
                     },
		 axisLine: {
            show: true
        },
        axisTick: {
            show: true
        },
        axisLabel: {
            textStyle: {
                color: '#000000'
            }
        }
    },
    dataZoom: [
        {
            type: 'inside'
        }
    ],
    series: [
        { // For shadow
            type: 'bar',
			barWidth : 60,
            itemStyle: {
                normal: {color: 'rgba(0,0,0,0.05)'}
            },
            barGap:'-100%',
            barCategoryGap:'40%',
            data: dataShadow,
            animation: false
        },
        {
            type: 'bar',
			barWidth : 60,
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: '#00BFFF'},
                            {offset: 0.5, color:'#00B2EE'},
                            {offset: 1, color: '#009ACD'}
                        ]
                    )
                },
                emphasis: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: '#00B0FF'},
                            {offset: 0.7, color: '#40C4FF'},
                            {offset: 1, color: '#80D8FF'}
                        ]
                    )
                }
            },
            data: dataX
        }
    ]
};
// Enable data zoom when user click bar.
var zoomSize = 6;
myChart.on('click', function (params) {
	//console.log(params);
	var name=params.name;
	myChart.dispatchAction({
        type: 'dataZoom',
        startValue: dataY[Math.max(params.dataIndex - zoomSize / 2, 0)],
        endValue: dataY[Math.min(params.dataIndex + zoomSize / 2, dataX.length - 1)]
    });
});
myChart.setOption(option);
}
});
</script>
</body>
</html>