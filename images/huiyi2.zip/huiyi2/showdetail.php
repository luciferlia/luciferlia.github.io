<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
$_search['id'] = $_GET['id'];
$sql="select * from calendar where id= '%{$_search["id"]}'";
	$result=mysql_query($sql);
	$array = array();
	if(! $result )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
    $array[]=$row;
	
} 
echo json_encode($array,JSON_UNESCAPED_UNICODE);

?>