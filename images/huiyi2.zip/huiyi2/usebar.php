<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
	 <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>
<script src="js/echarts.js"></script>
<style>
li {
	float:left;
}
body{background-color:#F5FFFA;}
li {
	float:left;
}

.disabled{
pointer-events:none; 
}
a{color:#00B2EE;}
.layui-table td{
	font-size:0.7em;
}
.top{
	
  background: -webkit-linear-gradient(#FFF0F5,#F0FFFF); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(#FFF0F5,#F0FFFF); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(#FFF0F5,#F0FFFF); /* Firefox 3.6 - 15 */
  background: linear-gradient(#FFF0F5,#F0FFFF); /* 标准的语法 */
position:fixed;
top:0;
height:60px;
opacity:1;
z-index:99;
	
}
#main{
   border:4px solid #DCDCDC;
	border-radius:25px;
	/*box-shadow:10px 10px 5px #888888;;}*/
}
/*body{background-color:#2F4F4F;}*/
</style>

<script>


var form;
	layui.use(['form', 'layedit', 'laydate'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
    laydate.render({
    elem: '#test1' //指定元素
  }); 
  laydate.render({
    elem: '#test2' //指定元素
  });  
  laydate.render({
    elem: '#test3' //指定元素
  });
});
function back(){
	var nowday=$('#test1').text();
	var nowday1 = nowday.replace(/\-/gi, "/");
	var time1 = new Date(nowday1).getTime();
	var back=new Date(time1-1*24*60*60*1000);
	var backtime=back.getFullYear()+"-"+(back.getMonth()+1)+"-"+back.getDate();
	document.getElementById('test1').innerHTML=backtime;
}
function prev(){
	var nowday=$('#test1').text();
	var nowday1 = nowday.replace(/\-/gi, "/");
	var time1 = new Date(nowday1).getTime();
	var prev=new Date(time1+1*24*60*60*1000);
	var prevtime=prev.getFullYear()+"-"+(prev.getMonth()+1)+"-"+prev.getDate();
	document.getElementById('test1').innerHTML=prevtime;
	
}

Date.prototype.Format=function(fmt) {         
    var o = {         
    "M+" : this.getMonth()+1, //月份         
    "d+" : this.getDate(), //日         
    "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时         
    "H+" : this.getHours(), //小时         
    "m+" : this.getMinutes(), //分         
    "s+" : this.getSeconds(), //秒         
    "q+" : Math.floor((this.getMonth()+3)/3), //季度         
    "S" : this.getMilliseconds() //毫秒         
    };         
    var week = {         
    "0" : "/u65e5",         
    "1" : "/u4e00",         
    "2" : "/u4e8c",         
    "3" : "/u4e09",         
    "4" : "/u56db",         
    "5" : "/u4e94",         
    "6" : "/u516d"        
    };         
    if(/(y+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));         
    }         
    if(/(E+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "/u661f/u671f" : "/u5468") : "")+week[this.getDay()+""]);         
    }         
    for(var k in o){         
        if(new RegExp("("+ k +")").test(fmt)){         
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));         
        }         
    }         
    return fmt;         
} 
$(document).ready(function (){
var time=new Date();
var now=new Date(time).Format("yyyy-MM-dd");
document.getElementById('test1').innerHTML=new Date(time).Format("yyyy-MM-dd");
document.getElementById('test2').innerHTML=new Date(time).Format("yyyy-MM-dd");
document.getElementById('test3').innerHTML=new Date(time).Format("yyyy-MM-dd");
})
 </script>
</head>
<body >
<div class="top" style="width:100%;min-width:1000px;">
<ul style="width:98%;margin-left:1%;margin-top:1%;" class="reportul">
<li>实验室使用情况  |</li>

<li>&nbsp;&nbsp;
<a onclick="back();" style="cursor:pointer;"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe603;</i></a>
&nbsp;&nbsp;</li>
<li><div id="test1" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
 <li><a onclick="prev();" style="cursor:pointer;"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe602;</i></a></li>
<li>&nbsp;&nbsp;查询范围：</li>
<li>&nbsp;&nbsp;从：</li>
<li><div id="test2" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
<li>&nbsp;&nbsp;到：</li>
<li><div id="test3" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
<li><a onclick="search();" style="cursor:pointer;"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe615;</i></a></li>
</ul>
	<hr class="layui-bg-green"/>
<div id="main" style="min-width:600px;width:80%;height:800px;margin-left:10%;margin-top:5%;"></div>
<script>
$.ajax({
	url:'all.php',
	type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(result){
		
		var str=JSON.parse(result);
		var dataY=new Array();
	   var dataX=new Array();
		for(i=0;i<str.length;i++){
			var dataA=str[i].lab;
			var dat=str[i].labsum;
			var jspn={value:dat,name:dataA};
			dataY.push(dataA);
			dataX.push(jspn);
		}
var myChart=echarts.init(document.getElementById('main'));



option = {
    title : {
        text: '实验室使用情况统计',
        subtext: '纯属虚构'
    },
    tooltip : {
        trigger: 'axis'
    },
    legend: {
        data:['迟到','延迟','未到']
    },
    toolbox: {
        show : true,
        feature : {
            dataView : {show: true, readOnly: false},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    calculable : true,
    xAxis : [
        {
            type : 'category',
            data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
        }
    ],
    yAxis : [
        {
            type : 'value'
        }
    ],
    series : [
        {
            name:'迟到',
            type:'bar',
            data:[2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3],
            markPoint : {
                data : [
                    {type : 'max', name: '最大值'},
                    {type : 'min', name: '最小值'}
                ]
            },
            markLine : {
                data : [
                    {type : 'average', name: '平均值'}
                ]
            }
        },
        {
            name:'延迟',
            type:'bar',
            data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3],
            markPoint : {
                data : [
                    {name : '年最高', value : 182.2, xAxis: 7, yAxis: 183},
                    {name : '年最低', value : 2.3, xAxis: 11, yAxis: 3}
                ]
            },
            markLine : {
                data : [
                    {type : 'average', name : '平均值'}
                ]
            }
        },
        {
            name:'未到',
            type:'bar',
            data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3],
            markPoint : {
                data : [
                    {name : '年最高', value : 182.2, xAxis: 7, yAxis: 183},
                    {name : '年最低', value : 2.3, xAxis: 11, yAxis: 3}
                ]
            },
            markLine : {
                data : [
                    {type : 'average', name : '平均值'}
                ]
            }
        }
    ]
};

myChart.setOption(option);
}
});
</script>
</body>
</html>