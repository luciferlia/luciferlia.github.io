<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
	 <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>
<script src="js/echarts.js"></script>
<style>
li {
	float:left;
}
body{background-color:#F5FFFA;}
li {
	float:left;
}

.disabled{
pointer-events:none; 
}
a{color:#00B2EE;}
.layui-table td{
	font-size:0.7em;
}
.top{
	
  background: -webkit-linear-gradient(#FFF0F5,#F0FFFF); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(#FFF0F5,#F0FFFF); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(#FFF0F5,#F0FFFF); /* Firefox 3.6 - 15 */
  background: linear-gradient(#FFF0F5,#F0FFFF); /* 标准的语法 */
position:fixed;
top:0;
height:60px;
opacity:1;
z-index:99;
	
}
#main{
   border:4px solid #DCDCDC;
	border-radius:25px;
	/*box-shadow:10px 10px 5px #888888;;}*/
}
/*body{background-color:#2F4F4F;}*/
</style>

<script>


var form;
	layui.use(['form', 'layedit', 'laydate'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
    laydate.render({
    elem: '#test1' //指定元素
  }); 
  laydate.render({
    elem: '#test2' //指定元素
  });  
  laydate.render({
    elem: '#test3' //指定元素
  });
});
function back(){
	var nowday=$('#test1').text();
	var nowday1 = nowday.replace(/\-/gi, "/");
	var time1 = new Date(nowday1).getTime();
	var back=new Date(time1-1*24*60*60*1000);
	var backtime=back.getFullYear()+"-"+(back.getMonth()+1)+"-"+back.getDate();
	document.getElementById('test1').innerHTML=backtime;
}
function prev(){
	var nowday=$('#test1').text();
	var nowday1 = nowday.replace(/\-/gi, "/");
	var time1 = new Date(nowday1).getTime();
	var prev=new Date(time1+1*24*60*60*1000);
	var prevtime=prev.getFullYear()+"-"+(prev.getMonth()+1)+"-"+prev.getDate();
	document.getElementById('test1').innerHTML=prevtime;
	
}

Date.prototype.Format=function(fmt) {         
    var o = {         
    "M+" : this.getMonth()+1, //月份         
    "d+" : this.getDate(), //日         
    "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时         
    "H+" : this.getHours(), //小时         
    "m+" : this.getMinutes(), //分         
    "s+" : this.getSeconds(), //秒         
    "q+" : Math.floor((this.getMonth()+3)/3), //季度         
    "S" : this.getMilliseconds() //毫秒         
    };         
    var week = {         
    "0" : "/u65e5",         
    "1" : "/u4e00",         
    "2" : "/u4e8c",         
    "3" : "/u4e09",         
    "4" : "/u56db",         
    "5" : "/u4e94",         
    "6" : "/u516d"        
    };         
    if(/(y+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));         
    }         
    if(/(E+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "/u661f/u671f" : "/u5468") : "")+week[this.getDay()+""]);         
    }         
    for(var k in o){         
        if(new RegExp("("+ k +")").test(fmt)){         
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));         
        }         
    }         
    return fmt;         
} 
$(document).ready(function (){
var time=new Date();
var now=new Date(time).Format("yyyy-MM-dd");
document.getElementById('test1').innerHTML=new Date(time).Format("yyyy-MM-dd");
document.getElementById('test2').innerHTML=new Date(time).Format("yyyy-MM-dd");
document.getElementById('test3').innerHTML=new Date(time).Format("yyyy-MM-dd");
})
 </script>
</head>
<body >
<div class="top" style="width:100%;min-width:1000px;">
<ul style="width:98%;margin-left:1%;margin-top:1%;" class="reportul">
<li>实验室使用情况  |</li>

<li>&nbsp;&nbsp;
<a onclick="back();" style="cursor:pointer;"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe603;</i></a>
&nbsp;&nbsp;</li>
<li><div id="test1" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
 <li><a onclick="prev();" style="cursor:pointer;"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe602;</i></a></li>
<li>&nbsp;&nbsp;查询范围：</li>
<li>&nbsp;&nbsp;从：</li>
<li><div id="test2" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
<li>&nbsp;&nbsp;到：</li>
<li><div id="test3" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
<li><a onclick="search();" style="cursor:pointer;"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe615;</i></a></li>
</ul>
	<hr class="layui-bg-green"/>
<div id="main" style="min-width:600px;width:80%;height:800px;margin-left:10%;margin-top:5%;"></div>
<script>
$.ajax({
	url:'all.php',
	type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(result){
		
		var str=JSON.parse(result);
		var dataY=new Array();
	   var dataX=new Array();
		for(i=0;i<str.length;i++){
			var dataA=str[i].lab;
			var dat=str[i].labsum;
			dataY.push(dataA);
			dataX.push(dat);
		}
		
var myChart=echarts.init(document.getElementById('main'));

var yMax = 25;
var dataShadow = [];

for (var i = 0; i < dataX.length; i++) {
    dataShadow.push(yMax);
}

option = {
    title: {
        text: '实验室使用情况',
        subtext: '点击可缩大或放小'
    },
	 toolbox: {
        show : true,
        feature : {
            dataView : {show: true, readOnly: false},
            magicType : {show: true, type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
	  tooltip: {
       
    },
    xAxis: {
        type: 'value',
       
		 axisTick: {
            show: true
        },
        axisLine: {
            show: true
        },
        z: 5
    },
	  
    yAxis: {
         type: 'category',
        data:dataY,
		 axisLabel:{
                 interval:0,
                 rotate:45,
                 margin:2,
                 textStyle:{
                         color:"#000000"
                         }
                     },
		 axisLine: {
            show: true
        },
        axisTick: {
            show: true
        },
        axisLabel: {
            textStyle: {
                color: '#000000'
            }
        }
    },
	 grid: { // 控制图的大小，调整下面这些值就可以，
             x: 170,
             x2: 100,
             y2: 50,// y2可以控制 X轴跟Zoom控件之间的间隔，避免以为倾斜后造成 label重叠到zoom上
         },
    dataZoom: [
        {
            type: 'inside'
        }
    ],
    series: [
        { // For shadow
            type: 'bar',
			barWidth : 60,
            itemStyle: {
                normal: {color: 'rgba(0,0,0,0.05)'}
            },
            barGap:'-100%',
            barCategoryGap:'40%',
            data: dataShadow,
            animation: false
        },
		
        {
            type: 'bar',
			barWidth : 60,
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: '#00BFFF'},
                            {offset: 0.5, color:'#00B2EE'},
                            {offset: 1, color: '#009ACD'}
                        ]
                    )
                },
                emphasis: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: '#00B0FF'},
                            {offset: 0.7, color: '#40C4FF'},
                            {offset: 1, color: '#80D8FF'}
                        ]
                    )
                }
            },
			
            data: dataX
        }
    ]
};
// Enable data zoom when user click bar.
var zoomSize = 6;
myChart.on('click', function (params) {
	//console.log(params);
	var name=params.name;
    //console.log(params.name);//bar的name
	window.location.href="devbar.php?lab="+name;//跳转到设备柱状图界面
	myChart.dispatchAction({
        type: 'dataZoom',
        startValue: dataY[Math.max(params.dataIndex - zoomSize / 2, 0)],
        endValue: dataY[Math.min(params.dataIndex + zoomSize / 2, dataX.length - 1)]
    });
});
myChart.setOption(option);
}
});
</script>
</body>
</html>