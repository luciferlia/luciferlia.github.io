<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
	 <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>
	<link rel="stylesheet" href="css/fm.selectator.jquery.css"/>
<style>
.reportul li {
	float:left;
}

a{color:#00B2EE;}
.selectator_option_title{font-size:1em;

}
/*#devtable td{border:1px solid red;}*/
.top{
	
  background: -webkit-linear-gradient(#FFF0F5,#F0FFFF); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(#FFF0F5,#F0FFFF); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(#FFF0F5,#F0FFFF); /* Firefox 3.6 - 15 */
  background: linear-gradient(#FFF0F5,#F0FFFF); /* 标准的语法 */

top:0;
height:30px;
opacity:1;
z-index:99;
	
}
.mytest{

display:-moz-inline-box;
display:inline-block;
  text-align: center;   
  text-decoration: none;
width: 100%;
height:auto; 
font-size:0.9em;
border:1px solid #8DEEEE;
border-radius:15px;
 box-shadow: 1px 9px #9C9C9C;
 }		
.calen{
position: absolute;
height:15px; 
font-size:0.8em;
border-radius:4px;
 }
 .clear{clear:both;}
.time:hover{background-color:#BFEFFF;}
#table td{border:1px dashed #CFCFCF;font-size:0.9em;

}
#table{position: absolute;}
.selectator_options li:hover{background-color:#008B8B;}
#addcontdev{
	height:auto;
	display:none;
	z-index:99999999;
	position: absolute;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
}
.table{left:0px;top:0px;width:100%;height:100%;z-index:1;position:absolute}
.table td{border:1px dashed #CFCFCF;font-size:0.9em;width:70px;}

.list{table-layout:fixed;left:0px;top:5px;width:100%;height:auto;z-index:2;position:absolute;}
.list td{width:70px;padding:0px;margin:0;font-size:0.7em;}
</style>

<script>

var form;
	layui.use(['form', 'layedit', 'laydate','element'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
  var element = layui.element;
  
  
  //执行一个laydate实例
  laydate.render({
    elem: '#startdate' //指定元素
	 ,type: 'datetime'
	 ,done: function(value, date, endDate){
		 var time=new Date();
		 var nowdate=new Date(time).Format("yyyy-MM-dd");//获取当前时间
		 console.log(value);
    var date=value.split(' ');
     var a=date[0].replace(/\-/gi,"/");
    var starts=new Date(a).getTime();//选择的时间的时间戳
	var  b=nowdate.replace(/\-/gi,"/");
	var now=new Date(b).getTime();//获取当前时间戳
	var eg=(starts-now)/(24*60*60*1000);
	if(eg>3){
		layer.msg("预约时间不得提前超过3天");
		
	}
	
  }
  });
    laydate.render({
    elem: '#enddate' //指定元素
	 ,type: 'datetime'
  });
  laydate.render({
    elem: '#testt' 
	 ,type: 'month'//指定元素
  });
  form.on('select(lab)', function(data){
  labselect(data);
  console.log(data.value); //得到被选中的值
});
});
 function getLocalTime(nS) {     
        return new Date(parseInt(nS) * 1000).toString().replace(/:\d{1,2}$/,' ');       
    }
function gethour(times){
	var tim=times.split(" ");
		var hour=tim[4];
		var hou=hour.split("/");
		var ho=hou[0];
		return ho;
}
function getday(times){
	var tim=times.split(" ");
		var day=tim[2];
		return day;
}
function getDaysInMonth(year,month){ month = parseInt(month,10); 
 var temp = new Date(year,month,0); return temp.getDate(); }

Date.prototype.Format=function(fmt) {         
    var o = {         
    "M+" : this.getMonth()+1, //月份         
    "d+" : this.getDate(), //日         
    "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时         
    "H+" : this.getHours(), //小时         
    "m+" : this.getMinutes(), //分         
    "s+" : this.getSeconds(), //秒         
    "q+" : Math.floor((this.getMonth()+3)/3), //季度         
    "S" : this.getMilliseconds() //毫秒         
    };         
    var week = {         
    "0" : "/u65e5",         
    "1" : "/u4e00",         
    "2" : "/u4e8c",         
    "3" : "/u4e09",         
    "4" : "/u56db",         
    "5" : "/u4e94",         
    "6" : "/u516d"        
    };         
    if(/(y+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));         
    }         
    if(/(E+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "/u661f/u671f" : "/u5468") : "")+week[this.getDay()+""]);         
    }         
    for(var k in o){         
        if(new RegExp("("+ k +")").test(fmt)){         
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));         
        }         
    }         
    return fmt;         
} 

function resulte(id,num){
//展示预约详情的列表
document.getElementById('chuid').value=id;	
var time=document.getElementById('testt').innerText;
var str=time.split("-");
var year=parseInt(str[0]);
var month=parseInt(str[1]);
//获取当月的天数
var mday=getDaysInMonth(year,month);
var endm=year+"-"+parseInt(month+1);
var a=time.replace(/\-/gi,"/");
var starts=new Date(a).getTime();//月初的时间戳
var b=endm.replace(/\-/gi,"/");
var ends=new Date(b).getTime();//月末的时间戳
//获取当前时间 去数据库查询当前实验室的当前日期的数据，
//处理，并返回，将数据放在相应地方，改变颜色
$.ajax({
	url:"calendar.php?id="+id+'&start='+time+'&end='+endm,
	type:"POST",
	dataType:'text',
	success:function(result){
	//alert(result)
	//获取了开始时间为当天的当前实验室的数据
     var str=JSON.parse(result);
	//当前数据是由数组组成的json数据，先转换
	//首先要匹配到table表中的设备，然后再匹配到对应小时时间
	//先循环table，再循环结果	
	for(i=0;i<str.length;i++)
	{
		var eventid=str[i].id;
		var title=str[i].title;
		var color=str[i].color;
		var dev_sty=str[i].dev_sty;
		//获取开始时间戳
		var time=str[i].starttime;	
		//获取开始时间的小时
		var shour=parseInt(new Date(time*1000).getHours());
		//获取开始时间天数
		var sday=parseInt(new Date(time*1000).getDate());
        //获取开始时间的月
		var smonth=parseInt(new Date(time*1000).getMonth()+1);
        //获取开始时间的年
         var sy=parseInt(new Date(time*1000).getFullYear());		
		var etime=str[i].endtime;		
		//获取结束时间的小时
		var ehour=parseInt(new Date(etime*1000).getHours());
		//获取结束时间天数
		var eday=parseInt(new Date(etime*1000).getDate());
        //获取结束时间的月
		var emonth=parseInt(new Date(etime*1000).getMonth()+1);
        //获取结束时间的年
        var ey=parseInt(new Date(etime*1000).getFullYear());
        //通用 头部和尾部
		var head='<tr style="height:11px;"><td style="width:38px;"></td>';
		var end='</tr>';
        //跨年情况，查询是否跨年
		if(ey>sy){
			
			
		}	
		//跨月
	    else if(emonth>smonth){
			//跨月，首先考虑两种情况
			//1.在本月显示的是开始
			//2.在本月是结束
			//3.在本月是过渡
		  
		  //判断月份是否是当前月
		  if(smonth==month){
			 //第一种，本月是开始，首先要获取本月天数,content部分分开始日+shour-24，剩余天数的0-24
            var content1='<td colspan="'+shour+'" style="width:'+(70*shour)+'px;"></td>'+
		 	'<td colspan="'+(24-shour)+'" style="width:'+(70*(24-shour))+'px;background-color:'+color+';" onclick="showd('+eventid+')" oncontextmenu="details('+eventid+',event)">'+title+'</td>';
		    $('#lists'+sday+'').append(head+content1+end);
			//连续的天
			for(t1=(sday+1);t1<(mday+1);t1++){
				var content2='<td colspan="24" style="width:'+(70*24)+'px;background-color:'+color+';" onclick="showd('+eventid+')" oncontextmenu="details('+eventid+',event)">'+title+'</td>';
			$('#lists'+t1+'').append(head+content2+end);
			}			 
		  }
		  
			
		}
		//跨天
        else if(eday>sday){
			//处理跨天，分三段，shour-24,1-24,1-ehour
			var content1='<td colspan="'+shour+'" style="width:'+(70*shour)+'px;"></td>'+
		 	'<td colspan="'+(24-shour)+'" style="width:'+(70*(24-shour))+'px;background-color:'+color+';" onclick="showd('+eventid+')" oncontextmenu="details('+eventid+',event)">'+title+'</td>';
		    $('#lists'+sday+'').append(head+content1+end);
			//连续的天
			for(t1=(sday+1);t1<eday;t1++){
				var content2='<td colspan="24" style="width:'+(70*24)+'px;background-color:'+color+';" onclick="showd('+eventid+')" oncontextmenu="details('+eventid+',event)">'+title+'</td>';
			$('#lists'+t1+'').append(head+content2+end);
			}
			//结束的天
			var content3='<td colspan="'+ehour+'" style="width:'+(70*ehour)+'px;background-color:'+color+';" onclick="showd('+eventid+')" oncontextmenu="details('+eventid+',event)">'+title+'</td>'+
			'<td colspan="'+(24-ehour)+'" style="width:'+(70*(24-ehour))+'px;"></td>';
			$('#lists'+eday+'').append(head+content3+end);
		}
        //同一天
		else{		  
			//处于当月，查找天，根据div的id和table的id查找，在id=lists+'eday'的table
			//判断开始小时和结束小时,然后生成一个tr，追加到id=lists+'eday'的table中
			//tr的第一个td固定为<td style="width:40px;"></td>
			var content='<td colspan="'+shour+'" style="width:'+(70*shour)+'px;"></td>'+
			'<td colspan="'+(ehour-shour)+'" style="background-color:'+color+';width:'+(70*parseInt((ehour-shour)))+'px;" onclick="showd('+eventid+')" oncontextmenu="details('+eventid+',event)">'+title+'</td>'+
			'<td colspan="'+(24-ehour)+'" style="width:'+(70*(24-ehour))+'px;"></td>';
            
           $('#lists'+sday+'').append(head+content+end);			  
		}
		
			
		
        		
	}		
	},
	error:function(errMsg){
	alert(errMsg);	
	}
	
});
	
}

$(document).ready(function (){
var time=new Date();
var year=parseInt(new Date(time).Format("yyyy"));
var month=parseInt(new Date(time).Format("MM"));
document.getElementById('testt').innerHTML=new Date(time).Format("yyyy-MM");
document.getElementById('startdate').value=new Date(time).Format("yyyy-MM-dd 00:00:00");
var ids=$('#li1').find('p.devids').text();

searchs();
resulte(ids,"1");
})

function searchs(){
	
	var time=document.getElementById('testt').innerText;
	var str=time.split("-");
	var year=parseInt(str[0]);
	var month=parseInt(str[1]);
	var days=getDaysInMonth(year,month);
var day=document.getElementById('calendar');
var html='';
for(i=1;i<=days;i++){
	html+='<div style="position:relative;height:70px;width:1720px;" id="t'+i+'"><table  class="table"><tr><td style="font-weight:bold;text-align:center;vertical-align:middle;width:40px;">'+i+'</td>'+
	'<td class="time t0" onclick="ordera(this);" ></td>'+
	'<td class="time t1" onclick="ordera(this);"></td>'+
	'<td class="time t2" onclick="ordera(this);"></td>'+
	'<td class="time t3" onclick="ordera(this);" ></td>'+
	'<td class="time t4" onclick="ordera(this);" ></td>'+
	'<td class="time t5" onclick="ordera(this);" ></td>'+
	'<td class="time t6" onclick="ordera(this);" ></td>'+
	'<td class="time t7" onclick="ordera(this);" ></td>'+
	'<td class="time t8" onclick="ordera(this);"></td>'+
	'<td class="time t9" onclick="ordera(this);" ></td>'+
	'<td class="time t10" onclick="ordera(this);"></td>'+
	'<td class="time t11" onclick="ordera(this);" ></td>'+
	'<td class="time t12" onclick="ordera(this);"></td>'+
	'<td class="time t13" onclick="ordera(this);"></td>'+
	'<td class="time t14" onclick="ordera(this);"></td>'+
	'<td class="time t15" onclick="ordera(this);" ></td>'+
	'<td class="time t16" onclick="ordera(this);" ></td>'+
	'<td class="time t17" onclick="ordera(this);"></td>'+
	'<td class="time t18" onclick="ordera(this);" ></td>'+
	'<td class="time t19" onclick="ordera(this);" ></td>'+
	'<td class="time t20" onclick="ordera(this);" ></td>'+
	'<td class="time t21" onclick="ordera(this);" ></td>'+
	'<td class="time t22" onclick="ordera(this);" ></td>'+
	'<td class="time t23" onclick="ordera(this);"></td>'+
	'</tr></table>'+'<table class="list" id="lists'+i+'" style="margin-top:2px;"></table></div>';
	} 
    
day.innerHTML=html;

}

function showyu(id,num){
	//id 该设备的id号 
	//num 对应的tab的div的id号
	resulte(id,num);

}
	
 </script>

</head>
<body>
<input id="chuid" type="hidden">
<div class="top" style="width:100%;min-width:1000px;">
<ul style="width:98%;margin-left:1%;" class="reportul">
<li>实验室使用情况  |</li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;<a onclick="order();" style="cursor:pointer;">
<i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe608;</i>预约</a>|</li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;<a onclick="showmark();" style="cursor:pointer;">
<i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe608;</i>预  sss约</a>|&nbsp;&nbsp;&nbsp;&nbsp;</li>

<li><div id="testt" style="height:20px;line-height:20px;width:90px;cursor:pointer;border-bottom:1px solid #e2e2e2;float:left;"></div></li>
<li><a onclick="searchs();" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe615;</i></a></li>
 <li style="float:right;"><a onclick="addlab();"><i class="layui-icon" style="font-size:15px;color:#2E8B57;">&#xe631;</i>实验室</a></li>
</ul>
	<hr class="layui-bg-green"/>

	<div class="layui-tab layui-tab-card"style="margin-top:11px;height:auto;border-top:1px solid #87CEFF;border-bottom:1px solid white;">
  <ul class="layui-tab-title" style="background-color:#87CEFF;border-left:1px solid #87CEFF;">
  <?php
	$_search['l_id'] = $_GET['id'];
	$query="select id,
				   dev_sty,
				   dev_mod,
				   remark
				   from dev
				   where l_id={$_search['l_id']}";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
				   $i=0;
			while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['id']=$_rows['id'];
            $date['dev_sty']=$_rows['dev_sty'];
            $date['dev_mod']=$_rows['dev_mod'];
            $date['remark']=$_rows['remark'];			
				$i++;
				if($i==1){
			?>
			
<li class="layui-this" id='li1'onclick="showyu(<?php echo "{$date['id']}"?>,<?php echo "{$i}"?>)"><p class="devids" style="display:none"><?php echo "{$date['id']}"?></p><p name="shdev"><?php echo "{$date['dev_sty']}"?><p></li>
<?php 
}
else{
	?>
	<li onclick="showyu(<?php echo "{$date['id']}"?>,<?php echo "{$i}"?>)"><?php echo "{$date['dev_sty']}"?></li>
	<?php
}
			}
			?>			
    
    
  </ul>
  <div class="layui-tab-content" style="height:auto;">
  <?php
  $_search['l_id'] = $_GET['id'];
	$query="select id,
				   dev_sty,
				   dev_mod,
				   remark
				   from dev
				   where l_id={$_search['l_id']}";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
				   $j=0;
			while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['id']=$_rows['id'];
            $date['dev_sty']=$_rows['dev_sty'];
            $date['dev_mod']=$_rows['dev_mod'];
            $date['remark']=$_rows['remark'];
  $j++;
	  if($j==1){
	?>
	<div class="layui-tab-item layui-show" id="lay<?php echo "{$j}"?>"> <p style="color:#EE2C2C;"><?php echo "{$date['dev_mod']}"?></p>
	
	<hr class="layui-bg-green"/><table style="TABLE-LAYOUT:fixed;WORD-BREAK:break-all;width:1720px;margin-left:0.3%;">
	<tr style="height:40px;">
	<td></td>
	<td>00</td>
<td>01</td>
<td>02</td>
<td>03</td>
<td>04</td>
<td>05</td>
<td>06</td>
<td>07</td>
<td>08</td>
<td>09</td>
<td>10</td>
<td>11</td>
<td>12</td>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
	</tr></table>
	</div> 
<?php
}
else
{
	$s=$j*5;
	?>
	<div class="layui-tab-item" id="lay<?php echo "{$j}"?>" style="height:auto;"><p style="color:#EE2C2C;margin-left:<?php echo "{$s}"?>%;"><?php echo "{$date['dev_mod']}"?></p>
	<hr class="layui-bg-green"/>
	<table style="TABLE-LAYOUT:fixed;WORD-BREAK:break-all;width:1720px;margin-left:0.3%;">
	<tr style="height:40px;">
	<td></td>
	<td>00</td>
<td>01</td>
<td>02</td>
<td>03</td>
<td>04</td>
<td>05</td>
<td>06</td>
<td>07</td>
<td>08</td>
<td>09</td>
<td>10</td>
<td>11</td>
<td>12</td>
<td>13</td>
<td>14</td>
<td>15</td>
<td>16</td>
<td>17</td>
<td>18</td>
<td>19</td>
<td>20</td>
<td>21</td>
<td>22</td>
<td>23</td>
	</tr></table>
	</div> 
	<?php

  }
			}
  ?>
   
  </div>
</div>
	
	
<label id="mylab" style="display:none;"><?php echo"{$_search['l_id']}"?></label>
	
	<!--<table style="TABLE-LAYOUT:fixed;WORD-BREAK:break-all;width:98%;margin-left:1%;height:100%;;min-width:1000px;" id="table" class="table">
	
<tbody id="days">

		</tbody>	
	</table>-->
	<div id="calendar">
	
	
	</div>
	<?php 
	$_search['l_id'] = $_GET['id'];
	$sql="select lab,onwer from lab where l_id={$_search['l_id']}";
	$result=mysql_query($sql)or die('SQL错误'.mysql_error());
				   $data=array();
			while(!!$_row=mysql_fetch_array($result,MYSQL_ASSOC)){
			$data['lab']=$_row['lab'];
			$data['onwer']=$_row['onwer'];
 
			}
			
	?>
	<span id="labsid" style="display:none;"><?php echo "{$_search['l_id']}"?></span>
	

	<div id="contracText" style="display:none;">
<form  id="add_form" action="do.php"method="post"  class="layui-form">

 <input type="hidden" name="action" value="add" id="action"></td>
  <td><input type="hidden" name="id" value="" id="ids"></td></tr>
<label><i class="layui-icon" style="font-size: 30px; color:#1E9FFF;;">&#xe60a;</i>  基本信息</label>
<hr class="layui-bg-green" style="width:90%;"/>
 <table  style="width:96%;height:60%;margin-left:2%;font-size:0.9em;">
 <tr ><td style="width:50px;">测试项：<a onclick="addc(this)" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe654;</i></a>
	</td>
  <td>
       <select class="event" name="event" lay-filter="feed"></select>
	</td><td>测试时间：<input type="text" name="" value="" style="width:50px;height:35px;border-radius:2px;border:1px solid #E8E8E8;"></td></tr>
   <tr><td>承载量：
	</td>
  <td>
	<input type="text" class="layui-input" style="width:250px" readonly> 
	
	</td><td></td></tr>
   <tr style="display:none;"><td>实验室类别：
	</td>
  <td>
	<input type="text" class="layui-input" id="lab" name="lab" value='<?php echo"{$_search['l_id']}"?>'style="width:250px" readonly> 
	
	</td><td></td></tr>
   <tr style="display:none;"><td>设备类别：
	</td>
  <td><input  id="dev_sty" name="dev_sty"class="layui-input"  lay-filter="dev" >        
	</td><td></td></tr>
   <tr style="display:none;"><td>设备型号：
	</td>
  <td><input type="text" class="layui-input" id="dev_mod" name="dev_mod"style="width:250px"> 
	</td><td></td></tr>
   <tr style="display:none;"><td>资源责任人：
	</td>
  <td><input type="text" class="layui-input" value='<?php echo "{$data['onwer']}"?>' id="onwer" name="onwer"style="width:250px"  readonly> 
	</td><td></td></tr>
   <tr><td>预订人：
	</td>
  <td><input type="text" name="user"class="layui-input" id="user"style="width:250px" value=""> 
	</td><td></td></tr>
   <tr><td>联系电话：
	</td>
  <td><input type="text" name="phone"class="layui-input" id="phone"style="width:250px" value=""> 
	</td><td></td></tr>
   <tr><td>使用项目：
	</td>
  <td><input type="text" name="project"class="layui-input" id="project"style="width:250px" value=""> 
	</td><td></td></tr>
   <tr><td>备注：
	</td>
  <td><input type="text"  id="remark" name="remark"class="layui-input"style="width:250px" value=""> 
	</td><td></td></tr></table>
<label><i class="layui-icon" style="font-size: 30px; color:#1E9FFF;;">&#xe637;</i>  时间范围选择</label>
<hr class="layui-bg-green" style="width:90%;"/>
<table  style="width:96%;height:auto;margin-left:2%;font-size:0.9em;">
 <tr ><td style="width:50px;">开始时间：
	</td>
  <td><input type="text" class="layui-input" name="startdate" id="startdate" value="" style="width:250px" readonly>
	</td></tr>
   <tr><td>结束时间：
	</td>
  <td><input type="text" class="layui-input" name="enddate" id="enddate" value="" style="width:250px" readonly>
   </td></tr></table>
</form>
</div>


<div id="addlab" style="display:none;">
<form  id="addlab_form" action="labse.php"method="post" class="layui-form" >
<table style="width:98%;height:100%;margin-left:1%;font-size:0.9em;" id="devtable">
<tr style="display:none;">
   <td style="width:50px;">实验室类别：
	</td>
    <td><input type="text" class="layui-input"name="lab" value='<?php echo "{$data['lab']}"?>'style="width:250px" readonly> 	
	</td>
	<td></td>
	<td></td>
	</tr>
  <tr><td>设备类别：
	</td>
    <td><input type="text" class="layui-input"name="dev_sty"style="width:250px">
	</td><td></td><td></td></tr>
  <tr><td>设备型号：
	</td>
    <td><input type="text" class="layui-input"name="dev_mod"style="width:250px"> 
	</td><td></td><td></td></tr>
  <tr><td>测试项：<a onclick="addcons(this);" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe654;</i></a>
	</td>
    <td><input type="text" class="layui-input"name="content"style="width:250px"> 
	</td><td>
	<a onclick="addcon(this,event);" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe61f;</i>关联设备</a>
	</td><td>测试时间：<input type="text" name="" value="" style="width:50px;height:35px;border-radius:2px;border:1px solid #E8E8E8;"></td></tr>
  <tr><td>备注：
	</td>
    <td><input type="text" class="layui-input"name="remark" style="width:250px"> 
	</td><td></td><td></td></tr>
  <tr><td>承载量：
	</td>
    <td><input type="text" class="layui-input"name="useable"style="width:250px"> 
	</td><td></td><td></td></tr>
  <tr><td>资源责任人：
	</td>
    <td><input type="text" class="layui-input"name="onwer"style="width:250px"> 
	</td><td><td></td></tr>
  </table>
</form>
</div>
<div style="display:none;font-size:0.9em;word-wrap:break-word;" id="bes">


<label><i class="layui-icon" style="font-size: 30px; color:#1E9FFF;;">&#xe60a;</i>  基本信息</label>
<hr class="layui-bg-green" style="width:90%;"/>
 <table style="margin-left:2%;"><tr style="height:30px;"><td>日程内容：</td>
	<td id="t1">测试</td>
	</tr>
   <tr style="height:30px;"><td>预订人：
	</td>
	<td id="t2">liaoqian</td>
	</tr>
  <tr style="height:30px;"><td>使用项目：
	</td>
	<td id="t3">A153</td>
	</tr>
    <tr style="height:30px;"><td>备注：
	</td>
	<td id="t4">
	</td>
	</tr>
    <tr style="height:30px;"><td>开始时间：
	</td>
	<td id="t5">2017-09-28 09:00</td>
	</tr>
    <tr style="height:30px;"><td>结束时间：
	</td>
	<td id="t6">2017-09-28 11:00</td>
	</tr>
 </table>


</div>


<div id="addcontdev" style="width:200px;">
<div align="right"
			style="padding:-2px;z-index:2000;font-size:12px;cursor:pointer;position:absolute;right:0;"
			onclick="hidd()">
			<span><i class="layui-icon" style="font-size:20px;">&#xe616;</i>  </span>
		</div>
<select  name="cons[]" id="cons" size="6"style="width:200px;height:50px;margin-top:5px;display:none;" data-selectator-keep-open="true" multiple>
	                    <?php
						$query="select 
	               id,
				  dev_sty
				   from dev
				   ";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
				  
				   
			while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['id']=$_rows['id'];
            $date['dev_sty']=$_rows['dev_sty'];
           			
						?>
						<option value="<?php echo "{$date['id']}"?>"><?php echo "{$date['dev_sty']}"?></option>
						<?php
			}
						?>
						
</select>	
<input value="activate selectator" id="activate_selectatorss" type="hidden">

</div>

</body>
	<script src="js/fm.selectator.jquery.js"></script>
<script>

function show(){//将传来的关于模块和测试内容的数据分解成数组
		  cities = new Object();
		 	
		 var rows = document.getElementById("table").rows.length; 
         var dev_sty=document.getElementById("dev_sty");
		 var html="";
		 for(var i=0;i<rows;i++)
		 {

		 var caseType=$("#table tr:eq('"+i+"') td:eq(0)").text();
		 var caseStore=$("#table tr:eq('"+i+"') td:eq(1)").text();
		 html +='<option value="'+caseType+'">'+caseType+'</option>'
       
		}
		dev_sty.innerHTML=html;
		form.render("select");	
}

		$(function(){
			
			var $activate_selectators = $('#activate_selectatorss');
			$activate_selectators.click(function () {
				var $selects = $('#cons');
				if ($selects.data('selectator') === undefined) {
					$selects.selectator({
						prefix: 'selectator_',
                        height: 'auto', 
                        useDimmer: false,						
						showAllOptionsOnFocus: true,
						keepOpen: true,
						selectFirstOptionOnSearch: true,
						 showAllOptionsOnFocus: true
					});
					$activate_selectators.val('destroy selectator');
				} else {
					$selects.selectator('destroy');
					$activate_selectators.val('activate selectator');
				}
			});
			$activate_selectators.trigger('click');

		});
function devselect(obj){
var devid=obj.value;
var dev_mod=document.getElementById("dev_mod");
var rows = document.getElementById("table").rows.length; 
for(var i=0;i<rows;i++)
		 {
		 var caseType=$("#table tr:eq('"+i+"') td:eq(0)").text();
		 var caseStore=$("#table tr:eq('"+i+"') td:eq(1)").text();
		if(devid==caseType)
		{			
			dev_mod.value=caseStore;
		}
		}

}
function order(){
	document.getElementById('dev_mod').value="";
	
	$("#dev_sty").val(dev_sty);
     form.render("select");	
	layer.open({
			type:1,
			title:'预定实验室',
			btn:['取消','确定'],
			
			skin:"layui-layer-molv",
			area: ['520px', '600px'], //宽高
			content:$("#contracText"),
			btn: ['确定', '取消']
           ,yes: function(){
			 var egs=times();
		   if(egs>3){
			   layer.msg("预约时间不得提前超过3天");
		   }
		   else{
           $("#add_form").submit();
			layer.closeAll();
		   }	
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  });
}
function idss(){
	var labid=$('#mylab').text();
	var did=document.getElementById('chuid').value;
	var event=document.getElementsByName('event');
	var stys=document.getElementById('dev_sty');
	var mods=document.getElementById('dev_mod');
	var html='';
	$.ajax({
	url:'shows.php?id='+labid,
	type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(result){
		var str=JSON.parse(result);
	  
		for(i=0;i<str.length;i++){
			var ids=str[i].id;
			var sty=str[i].dev_sty;
			var mod=str[i].dev_mod;
			var content=str[i].content;
			if(ids==did){
				stys.value=ids;
				mods.value=mod;
				var strd=content.split("、");
				for(j=0;j<strd.length;j++)
				{
					
					html +='<option value="'+strd[j]+'">'+strd[j]+'</option>';
				}
				for(l=0;l<event.length;l++){
					event[l].innerHTML=html;
					form.render("select");	
				}
				
					
				
			}
			
		}
	
	},
	error:function(errMsg){
		alert("加载失败");
	}
	
	
});
}
function ordera(obj){
	var time=new Date();
var num=$(obj).parents("tr").find("td").index($(obj))-1;
document.getElementById('startdate').value=new Date(time).Format("yyyy-MM-dd "+num+":00:00");
	
	var tr=obj.parentNode;
	idss();
	layer.open({
			type:1,
			title:'预定实验室',
			
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['520px', '600px'], //宽高
			content:$("#contracText"),
			btn: ['确定', '取消']
           ,yes: function(){
			 var egs=times();
		   if(egs>3){
			   layer.msg("预约时间不得提前超过3天");
		   }
		   else{
           $("#add_form").submit();
			layer.closeAll();
		   }	
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  });
}

function times(){
	
	var time=new Date();
		 var nowdate=new Date(time).Format("yyyy-MM-dd");//获取当前时间
		 var value=document.getElementById('startdate').value;
    var date=value.split(' ');
     var a=date[0].replace(/\-/gi,"/");
    var starts=new Date(a).getTime();//选择的时间的时间戳
	var  b=nowdate.replace(/\-/gi,"/");
	var now=new Date(b).getTime();//获取当前时间戳
	var eg=(starts-now)/(24*60*60*1000);
	return eg;
	
}


function addlab(){
	
	layer.open({
			type:1,
			title:'增加实验室设备',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['520px', '460px'], //宽高
			content:$("#addlab"),
			btn: ['确定', '取消']
           ,yes: function(){
			 
           $("#addlab_form").submit();
			layer.closeAll();
				 $('#addcontdev').hide();
           },cancel: function(index, layero){ 
  $('#addcontdev').hide();
            }    
           ,btn2: function(){
           layer.closeAll();
		    $('#addcontdev').hide();
          }					
		  });
	
}

function showd(id){
	event.cancelBubble = true
	var ids=id;
	layer.confirm('删除还是编辑预约？', {
  btn: ['删除', '编辑', '完成'] //可以无限个按钮
  ,btn3: function(index, layero){
   layer.closeAll();
  }
}, function(index, layero){
  window.location.href='search.php?id='+ids+'&action=0';
}, 
function(index){
  
    $.ajax({  
             url: "search.php?id="+ids+'&action=1',    
             type: "POST",  
             dataType: 'text',
             error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
             success: function(data){//如果调用php成功   
             document.getElementById("action").value='update';
               	
               var str=JSON.parse(data);
			   var id=str.id;
			   var title=str.title;
			   var starttime=str.starttime;
			   var endtime=str.endtime;
			   var lab=str.l_id;
			   var dev_sty=str.d_id;
			   var dev_mod=str.dev_mod;
			   var onwer=str.onwer;
			   var user=str.user;
			   var project=str.project;
			   var remark=str.remark;
			   var start=getLocalTime(starttime);
			   var st=new Date(start).Format("yyyy-MM-dd HH:mm:ss");
			   var end=getLocalTime(endtime);
			   var ed=new Date(end).Format("yyyy-MM-dd HH:mm:ss");
			  
			  
			  document.getElementById("ids").value=id;
			  document.getElementById("event").value=title;
			  document.getElementById("startdate").value=st;
			  document.getElementById("enddate").value=ed;
			  document.getElementById("lab").value=lab;
			  document.getElementById("dev_sty").value=dev_sty;
			  document.getElementById("dev_mod").value=dev_mod;
			  document.getElementById("onwer").value=onwer;
			  document.getElementById("user").value=user;
			  document.getElementById("project").value=project;
			  document.getElementById("remark").value=remark;
			layer.open({
			type:1,
			title:'修改预定实验室信息',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['620px', '600px'], //宽高
			content:$("#contracText"),
			btn: ['确定', '取消']
           ,yes: function(){
           var egs=times();
		   if(egs>3){
			   layer.msg("预约时间不得提前超过3天");
		   }
		   else{
           $("#add_form").submit();
			layer.closeAll();
			reset();
}			
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  }); 
			 }
			 
			  });
  
  
  
});
	
}
var menu=document.getElementById('bes');
function details(id,e){

 window.event.returnValue = false;
  var e = e || window.event;
  //鼠标点的坐标
  var oX = e.clientX;
  var oY = e.clientY;
  //菜单出现后的位置

	$.ajax({
		url:"search.php?id="+id+'&action=1',
		type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(data){
		       var str=JSON.parse(data);
			  
			   var title=str.title;
			   var starttime=str.starttime;
			   var endtime=str.endtime;
			   var lab=str.l_id;
			   var user=str.user;
			   var project=str.project;
			   var remark=str.remark;
			   var start=getLocalTime(starttime);
			   var st=new Date(start).Format("yyyy-MM-dd HH:mm:ss");
			   var end=getLocalTime(endtime);
			   var ed=new Date(end).Format("yyyy-MM-dd HH:mm:ss");
			   document.getElementById('t1').innerHTML=title;
			    document.getElementById('t2').innerHTML=user;
				 document.getElementById('t3').innerHTML=project;
				  document.getElementById('t4').innerHTML=remark;
				   document.getElementById('t5').innerHTML=st;
				    document.getElementById('t6').innerHTML=ed;
			   layer.open({
	            type: 1,
				title:false,
				offset: [oY,oX],
				shadeClose:true,
				closeBtn: 0,
				skin: 'layui-layer-rim', //加上边框
				area: ['300px', 'auto'], //宽高
			   
				content:$("#bes")
				
	              });
	}
		
	});
	
	}
	
	
	
	function addcon(obj,e){
		window.event.returnValue = false;
  var e = e || window.event;
  //鼠标点的坐标
  var oX = e.clientX;
  var oY = e.clientY;
  //菜单出现后的位置

  
  $('#addcontdev').css('margin-top',oY+10);
    $('#addcontdev').css('margin-left',oX-30);
		/*layer.open({
			type:1,
			title:false,
			shade:false,
			offset: [oY-20,oX-20],
			skin:"layui-layer-molv",
			
			area: ['220px','200px'], //宽高
			content:$("#addcontdev"),
			cancel: function(index, layero){ 
            //点击右上角的×后的动作
			
              }  
		  });*/
		    var s=$('#addcontdev').css('display');
		if(s=='none'){
			 $('#addcontdev').show();
			   $('#cons').selectator('refresh');
		  }
		  else{
			  $('#addcontdev').hide();
			    $('#cons').selectator('refresh');
		  }
		 
		 
		 
		
		
	}
	function addcons(obj){
		var tr=obj.parentNode.parentNode;
		var html='<tr><td><a onclick="deletecons(this);" style="cursor:pointer;float:right;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe640;</i></a></td>'+
		'<td><input type="text" class="layui-input"name="content"style="width:250px"> </td>'+
		'<td><a onclick="addcon(this,event);" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe61f;</i>关联设备</td>'+
		'<td></a>测试时间：<input type="text" name="" value="" style="width:50px;height:35px;border-radius:2px;border:1px solid #E8E8E8;"></td></tr>';
		$(tr).after(html);
		
	}
		function addc(obj){
		var tr=obj.parentNode.parentNode;
		var html='<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a onclick="addc(this)" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe654;</i></a><a onclick="deletecons(this);" style="cursor:pointer;float:right;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe640;</i></a></td>'+
		'<td> <select class="event" name="event" lay-filter="feed"></select></td>'+
		'<td>测试时间：<input type="text" name="" value="" style="width:50px;height:35px;border-radius:2px;border:1px solid #E8E8E8;"></td></tr>';
		$(tr).after(html);
		idss();
	}
	function hidd(){
		$('#addcontdev').hide();
		//叉掉之后的操作，暂时设计成将数据保存写入到隐藏域
		
	}
	function deletecons(obj){
		var tr=obj.parentNode.parentNode;
		$(tr).remove();
	}
</script>
</html>