<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>


<style>
li {
	float:left;
}

button{color:black;cursor:pointer;}

.layui-table td{
	font-size:0.7em;
}

.sek{width:100px;}
.button {
    background-color: #4682B4;
    border: none;
    color: white;
    padding: 2px 3px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 0.6em;
    margin: 2px 1px;
    cursor: pointer;
    border-radius: 2px;
}
.button:hover{background-color: #104E8B;}
</style>

<script>


var form;
	layui.use(['form', 'layedit', 'laydate','element'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
   var element = layui.element;
    form.on('select(feed)', function(data){
  feedu(data.elem);});
});


 var pageSize=12;  //每页显示的记录条数   
        var curPage=0;   //显示第curPage页
        var len;         //总行数
        var page;        //总页数    
    $(function(){    
len =$("#tables tr").length-1;   //去掉表头     
 page=len % pageSize==0 ? len/pageSize : Math.floor(len/pageSize)+1;//根据记录条数，计算页数

 document.getElementById("page").innerHTML=page;
  for(var j=1;j<page+1;j++)
		{
		$('#curPage').append('<option value='+j+'>'+j+'</option>');
		}
 curPage=1;
 displayPage();//显示第一页
$("#nextpage").click(function(){//下一页
   if(curPage<page){
       curPage+=1;
   }
   else{
       layer.msg("已经是最后一页");
   }
  displayPage();
  });
$("#lastpage").click(function(){//上一页
   if(curPage>1){
       curPage-=1;
   }
   else{
     layer.msg("已经是第一页");
   }
   displayPage();
   });
$("#npage").click(function(){//跳到固定某一页
   var npage=parseInt(document.getElementById("curPage").value);
   if(npage>page||npage<1){
      layer.msg("该页不存在");
   }
   else{
       curPage=npage;
   }
   displayPage();
   });
});

function displayPage(){  
var begin=(curPage-1)*pageSize;//起始记录号
var end = begin + pageSize;

if(end > len ) end=len;
$("#tables tr").hide();
$("#tables tr").each(function(i){
  if(i-1>=begin && i-1<end)//显示第page页的记录
      {
      $("#show_tab_one").show();
      $(this).show();      
      document.getElementById("curPage1").innerHTML=curPage;

      }         
});

}        
function pageSize(){
curPage=0;   //显示第curPage页   
pageSize=parseInt(document.getElementById("pageSize").value);
len =$("#tables tr").length-1;   //去掉表头     
page=len % pageSize==0 ? len/pageSize : Math.floor(len/pageSize)+1;//根据记录条数，计算页数
curPage=1;
displayPage();//显示第一页   
}
            
 </script>

</head>
<body>

<a onclick="addlab();" style="margin-top:2%;margin-left:1%;"><i class="layui-icon" style="font-size:25px;color:#2E8B57;">&#xe631;</i>实验室</a>
	
	<a href="editlab.php" style="margin-top:2%;margin-left:90%;"><i class="layui-icon" style="font-size:25px;color:#2E8B57;">&#xe631;</i>编辑</a>
	
	<hr class="layui-bg-green"/>
	<form class="layui-form">
	<table class="layui-table"id="tables"style="TABLE-LAYOUT:fixed;WORD-BREAK:break-all;width:100%;margin-top:0px;" lay-skin="line" >
<tr style="background-color:#FFF0F5;height:30px;"  id="show_tab_one"><td>预定名称</td><td>实验室</td>
<td>设备类别</td><td>设备型号</td>
<td>预订人</td><td>开始时间</td>
<td>结束时间</td><td>状态</td><td>评价</td></tr>
<tbody id="show_tab_tr">  
<?php
	$query="select title,
	               lab,
				   dev_sty,
				   dev_mod,
				   starttime,
				   endtime,
				   user,
				   status
				   from calendar";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
			while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['title']=$_rows['title'];
            $date['lab']=$_rows['lab'];
            $date['dev_sty']=$_rows['dev_sty'];
            $date['dev_mod']=$_rows['dev_mod'];
			$date['starttime']=date('Y-m-d H:i',$_rows['starttime']);//事件开始时间 
            $date['endtime']=date('Y-m-d H:i',$_rows['endtime']);//结束时间 
			$date['user']=$_rows['user'];	
            $date['status']=$_rows['status'];			
				
			?>	   

<tr>
    <td><?php echo "{$date['title']}"?></td>
	<td><?php echo "{$date['lab']}"?></td>
	<td><?php echo "{$date['dev_sty']}"?></td>
	<td><?php echo "{$date['dev_mod']}"?></td>
	<td><?php echo "{$date['user']}"?></td>
	<td><?php echo "{$date['starttime']}"?></td>
	<td><?php echo "{$date['endtime']}"?></td>
	<td><?php echo "{$date['status']}"?></td>
	<td><select class="sel" name="feed" lay-filter="feed"><option value="准时">准时<option>
	<option value="迟到">迟到<option>
	<option value="延迟">延迟<option>
	<option value="未到">未到<option></select></td>
	</tr>	
			<?php 
			}
			?>
			</tbody>
</table>
	</form>
	 <table style="width:100%;font-size:0.9em;"><tr><td>
                    共&nbsp;&nbsp;<span id="page" ></span>&nbsp;&nbsp;页&nbsp;&nbsp;|&nbsp;&nbsp;第&nbsp;&nbsp;<span id="curPage1"></span>&nbsp;&nbsp;页
                     <span style="float:right;">
                    <input id="lastpage" type="button" value="上一页" class="button">
   <input id="nextpage" type="button" value="下一页" class="button">
   <select id="curPage"></select>
    <input id="npage" type="button" value="确定" class="button"></span>
   
    </td></tr></table>
<div id="feed" style="display:none;">
<label style="margin-left:35%;margin-top:1%;"><i class="layui-icon" style="font-size: 25px; color:#1E9FFF;;">&#xe6b2;</i><span id="seld"></span>情况填写</label>
<hr class="layui-bg-green" style="width:100%;"/>
<form id="feedform" action=""method="post" class="layui-form" > 
<div class="layui-form-item">
    <label class="layui-form-label">浪费时间：
	</label>
    <div class="layui-input-block"><input type="text" name="" style="width:200px;" class="layui-input">
	</div>
  </div>
 <div class="layui-form-item">
    <label class="layui-form-label"><span id="selds"></span>原因：
	</label>
    <div class="layui-input-block"><textarea placeholder="请输入内容" name="" class="layui-textarea" style="width:350px;"></textarea>
	</div>
  </div>
   
</form>
</div>

</body>
<script>
function showdev(id){
	window.location.href="devlist.php?id="+id;
	  		 
}
function feedu(obj){
var re=obj.value;
if(re=='迟到'||re=='延迟'||re=='未到')
{
	document.getElementById('seld').innerHTML=re;
	document.getElementById('selds').innerHTML=re;
	layer.open({
			type:1,
			title:'增加实验室',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['520px', '360px'], //宽高
			content:$("#feed"),
			btn: ['确定', '取消']
           ,yes: function(){
			 
           $("#feedform").submit();
			layer.closeAll();
				
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  });
		  }
	
}
</script>
</html>