<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
    $lab = stripslashes(trim($_POST['lab']));//事件内容
	$lab=mysql_real_escape_string(strip_tags($lab),$link); //过滤HTML标签，并转义特殊字符
   
	$dev_sty=$_POST['dev_sty'];
	$dev_mod=$_POST['dev_mod'];
	$onwer=$_POST['onwer'];
	$useable=$_POST['useable'];
	$remark=$_POST['remark'];

	
	$query = mysql_query("insert into `lab` (`lab`,`dev_sty`,`dev_mod`,`onwer`,`useable`,`remark`) 
	values ('$lab','$dev_sty','$dev_mod','$onwer','$useable','$remark')");
	if(mysql_insert_id()>0){
		Header("HTTP/1.1 303 See Other"); 
Header("Location: lab.php"); 
exit; //from www.w3sky.com 
	}else{
		echo '写入失败！';
	}
   

?>