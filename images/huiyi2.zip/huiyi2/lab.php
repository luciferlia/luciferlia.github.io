<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>


<style>
li {
	float:left;
}

button{color:black;cursor:pointer;}

.layui-table td{
	font-size:0.7em;
}


.mytest{
  background: linear-gradient(-45deg,#00BFFF,#40E0D0);
display:-moz-inline-box;
display:inline-block;
  text-align: center;   
  text-decoration: none;
width: 20%;
height:90px; 
font-size:0.9em;
border:1px solid #8DEEEE;
border-radius:15px;
 box-shadow: 1px 9px #9C9C9C;
 margin:5px 5px 5px 5px;
 transition: all 0.3s;
 font-weight:bold;
 }		
.mytest p {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}
.mytest:hover{
	 box-shadow: 0 5px #666;
  transform: translateY(4px);
  color:white;
  font-size:1em;
}
.mytest p:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.1s;
}

.mytest:hover p {
  padding-right: 25px;
}

.mytest:hover p:after {
  opacity: 1;
  right: 0;
 
}        
.mytest:before{
	content:'';
  background: rgba(255, 255, 255, 0.3);
  height: 90px;
  width: 45px;
   top: 0;
  left: 70px;
	position:absolute;
	transform:skew(-45deg);
	transition:0s;
}	
.mytest:hover:before{
	
	left:70%;
	transition:.3s;
}		
		.scroll{  display:inline-block;
                         _zoom:1;
                         _display:inline;}
						
</style>

<script>


var form;
	layui.use(['form', 'layedit', 'laydate','element'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
   var element = layui.element;
});
$(document).ready(function (){
	
	var wen=document.getElementsByName('wen');
	for(i=0;i<wen.length;i++){
		var wenz=wen[i].innerText;
		var str=wenz.split("室");
		wen[i].innerHTML=str[0]+"室"+"<br/>"+str[1];
	}
})

 </script>

</head>
<body>
<ul style="margin-top:1%;"><li >
<a onclick="addlab();" ><i class="layui-icon" style="font-size:25px;color:#2E8B57;">&#xe631;</i>实验室</a>
	</li><li style="float:right;">
	<a href="editlab.php" ><i class="layui-icon" style="font-size:25px;color:#2E8B57;">&#xe631;</i>编辑</a>&nbsp;&nbsp;&nbsp;&nbsp;
	</li></ul>
	<hr class="layui-bg-green"/>
	<div style="width:85%;height:auto;margin-left:10%;margin-top:1%;">
	
	<?php
	$query="select l_id,
	               lab,
				   onwer,
				   remark
				   from lab
				   ";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
				   $i=0;
				   
			while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['l_id']=$_rows['l_id'];
            $date['lab']=$_rows['lab'];
            $date['onwer']=$_rows['onwer'];
            $date['remark']=$_rows['remark'];			
			$i++;
			
			if($i%4==0)
			{
			?>	   
	<button   class="mytest" onclick="showdev(<?php echo "{$date['l_id']}"?>)"><p name="wen"><?php echo "{$date['lab']}"?></p></button><br/>

<?php 
}
else{
	?>
	<button   class="mytest" onclick="showdev(<?php echo "{$date['l_id']}"?>)"><p name="wen"><?php echo "{$date['lab']}"?></p></button>
	
<?php } 
}
?>
	</div>		
	
<div id="addlab" style="display:none;">
<form  id="addlab_form" action=""method="post" class="layui-form" >
<div class="layui-form-item">
    <label class="layui-form-label">实验室类别：
	</label>
    <div class="layui-input-block" ><input type="text" class="layui-input" name="lab"style="width:250px">
  
	</div>
  </div>
 <div class="layui-form-item">
    <label class="layui-form-label">资源责任人：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input"name="onwer"style="width:250px"> 
	</div>
  </div>
   <div class="layui-form-item">
    <label class="layui-form-label">备注：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input"name="remark" style="width:250px"> 
	</div>
  </div>

 
</form>
</div>

</body>
<script>
function showdev(id){
	window.location.href="devlist.php?id="+id;
	  		 
}
function addlab(){
	layer.open({
			type:1,
			title:'增加实验室',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['520px', '360px'], //宽高
			content:$("#addlab"),
			btn: ['确定', '取消']
           ,yes: function(){
			 
           $("#addlab_form").submit();
			layer.closeAll();
				
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  });
	
}
</script>
</html>