<?php
include_once('connect.php');//连接数据库
$action = $_POST['action'];
if($action=='add'){
	
	//$events = stripslashes(trim($_POST['event']));//事件内容
	 $event=implode(" ",$_POST['event']);//获取的测试内容是数组。需要转换成字符串
	//$event=mysql_real_escape_string(strip_tags($event),$link); //过滤HTML标签，并转义特殊字符
    $lab=$_POST['lab'];//实验室
	$dev_sty=$_POST['dev_sty'];
	$dev_mod=$_POST['dev_mod'];
	$onwer=$_POST['onwer'];
	$user=$_POST['user'];
	$project=$_POST['project'];
	$remark=$_POST['remark'];

	$startdate = trim($_POST['startdate']);//开始日期
	$enddate = trim($_POST['enddate']);//结束日期
    $starttime=strtotime($startdate);
	$endtime=strtotime($enddate);
	$colors = array("#228B22","#f30","#06c","#FFB6C1","	#00B2EE","#698B22","#00868B");
	$key = array_rand($colors);
	$color = $colors[$key];
	
	$query = mysql_query("insert into `calendar` (`title`,`l_id`,`d_id`,`dev_mod`,`onwer`,`user`,`project`,`remark`,`starttime`,`endtime`,`allday`,`color`,`status`) 
	values ('$event','$lab','$dev_sty','$dev_mod','$onwer','$user','$project','$remark','$starttime','$endtime','0','$color','正常')");
	if(mysql_insert_id()>0){
		Header("HTTP/1.1 303 See Other"); 
Header("Location: cal_opt.php"); 
exit; //from www.w3sky.com 
	}else{
		echo '写入失败！';
	}
}
else{
	
	$events = stripslashes(trim($_POST['event']));//事件内容
	$events=mysql_real_escape_string(strip_tags($events),$link); //过滤HTML标签，并转义特殊字符
	$id=$_POST['id'];//实验室
    $lab=$_POST['lab'];//实验室
	$dev_sty=$_POST['dev_sty'];
	$dev_mod=$_POST['dev_mod'];
	$onwer=$_POST['onwer'];
	$user=$_POST['user'];
	$project=$_POST['project'];
	$remark=$_POST['remark'];

	$startdate = trim($_POST['startdate']);//开始日期
	$enddate = trim($_POST['enddate']);//结束日期
    $starttime=strtotime($startdate);
	$endtime=strtotime($enddate);
	$colors = array("#360","#f30","#06c");
	$key = array_rand($colors);
	$color = $colors[$key];
	
 mysql_query("UPDATE calendar
        SET title='$events',starttime='$starttime',endtime='$endtime',lab='$lab',dev_sty='$dev_sty',dev_mod='$dev_mod',onwer='$onwer',user='$user',project='$project',remark='$remark'
        WHERE id=$id")or die('SQL错误'.mysql_error());
			Header("HTTP/1.1 303 See Other"); 
Header("Location: cal_opt.php"); 
exit; //from www.w3sky.com 
	
}

?>