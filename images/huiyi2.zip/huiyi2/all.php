<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
$sql="select lab,count(*) as labsum from calendar group by lab";
	$result=mysql_query($sql);
	$array = array();
	if(! $result )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
    $array[]=$row;
	
} 
$date = trim('2017-09-27');
$times=strtotime($date);
$endtimes=$times+1*24*60*60*1000;
echo json_encode($array,JSON_UNESCAPED_UNICODE);

?>