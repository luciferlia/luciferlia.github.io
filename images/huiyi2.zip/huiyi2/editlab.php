<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="UTF-8">
<title>与德测试信息管理系统</title>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.js"></script>
<script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
<link rel="stylesheet" href="layui/css/layui.css" media="all">
<script src="layui/layui.js"></script>


<style>
li {
	float:left;
}

a{color:black;cursor:pointer;}

.layui-table td{
	font-size:0.7em;
}
.table td{border:1px solid #DCDCDC;
vertical-align:middle;
font-size:0.9em;}
.header td{color:white;text-align:center;}
.table tbody tr:hover{background-color:#FFF0F5;}
.table tr{height:40px;}
.button {
    background-color: #4682B4;
    border: none;
    color: white;
    padding: 2px 3px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 0.6em;
    margin: 2px 1px;
    cursor: pointer;
    border-radius: 2px;
}
.button:hover{background-color: #104E8B;}
</style>

<script>


var form;
	layui.use(['form', 'layedit', 'laydate','element'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
   var element = layui.element;
});
var pageSize=12;  //每页显示的记录条数   
        var curPage=0;   //显示第curPage页
        var len;         //总行数
        var page;        //总页数    
    $(function(){    
len =$("#tables tr").length-1;   //去掉表头     
 page=len % pageSize==0 ? len/pageSize : Math.floor(len/pageSize)+1;//根据记录条数，计算页数

 document.getElementById("page").innerHTML=page;
  for(var j=1;j<page+1;j++)
		{
		$('#curPage').append('<option value='+j+'>'+j+'</option>');
		}
 curPage=1;
 displayPage();//显示第一页
$("#nextpage").click(function(){//下一页
   if(curPage<page){
       curPage+=1;
   }
   else{
       layer.msg("已经是最后一页");
   }
  displayPage();
  });
$("#lastpage").click(function(){//上一页
   if(curPage>1){
       curPage-=1;
   }
   else{
     layer.msg("已经是第一页");
   }
   displayPage();
   });
$("#npage").click(function(){//跳到固定某一页
   var npage=parseInt(document.getElementById("curPage").value);
   if(npage>page||npage<1){
      layer.msg("该页不存在");
   }
   else{
       curPage=npage;
   }
   displayPage();
   });
});

function displayPage(){  
var begin=(curPage-1)*pageSize;//起始记录号
var end = begin + pageSize;

if(end > len ) end=len;
$("#tables tr").hide();
$("#tables tr").each(function(i){
  if(i-1>=begin && i-1<end)//显示第page页的记录
      {
      $("#show_tab_one").show();
      $(this).show();      
      document.getElementById("curPage1").innerHTML=curPage;

      }         
});

}        
function pageSize(){
curPage=0;   //显示第curPage页   
pageSize=parseInt(document.getElementById("pageSize").value);
len =$("#tables tr").length-1;   //去掉表头     
page=len % pageSize==0 ? len/pageSize : Math.floor(len/pageSize)+1;//根据记录条数，计算页数
curPage=1;
displayPage();//显示第一页   
}
 </script>

</head>
<body>


	
	<hr class="layui-bg-green"/>
	
	<table class="table"  id="tables"
				style="TABLE-LAYOUT:fixed;WORD-BREAK:break-all;width:95%;margin-left:2%;">
	<tr  style="background-color:#4682B4;height:40px;"id="show_tab_one" class="header">
	<td style="display:none;"></td><td>实验室</td><td>设备</td><td>型号</td><td style="width:80px;">可并行数</td><td>测试项</td><td>管理者</td><td style="width:80px;">设备状态</td><td style="width:100px;">操作</td></tr>
	
	<tbody id="show_tab_tr"><?php
	$query="select id,
	               lab,
				   dev_sty,
				   dev_mod,
				   useable,
				   content
				   from dev
				   ";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
				  
				   
			while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['id']=$_rows['id'];
            $date['lab']=$_rows['lab'];
            $date['dev_sty']=$_rows['dev_sty'];
            $date['dev_mod']=$_rows['dev_mod'];
            $date['useable']=$_rows['useable'];
            $date['content']=$_rows['content'];			
			?>	 
<tr>
<td style="display:none;"> <?php echo "{$date['id']}"?></td>
	<td style="text-align:center;"> <?php echo "{$date['lab']}"?></td>
       <td style="text-align:center;"> <?php echo "{$date['dev_sty']}"?></td>
	   <td style="text-align:center;"> <?php echo "{$date['dev_mod']}"?></td>
	   <td style="text-align:center;"> <?php echo "{$date['useable']}"?></td>
	   <td> <?php echo "{$date['content']}"?></td>
	   <td style="text-align:center;"></td>
	    <td style="text-align:center;"></td>
	    <td style="text-align:center;"><a onclick="edit(this)">编辑</a> | <a onclick="deletes(this)">删除</a></td>
</tr>
<?php 
}
?>
</tbody>
	</table>
<table style="width:95%;margin-left:2%;font-size:0.9em;"><tr><td>
                    共&nbsp;&nbsp;<span id="page" ></span>&nbsp;&nbsp;页&nbsp;&nbsp;|&nbsp;&nbsp;第&nbsp;&nbsp;<span id="curPage1"></span>&nbsp;&nbsp;页
                     <span style="float:right;">
                    <input id="lastpage" type="button" value="上一页" class="button">
   <input id="nextpage" type="button" value="下一页" class="button">
   <select id="curPage"></select>
    <input id="npage" type="button" value="确定" class="button"></span>
   
    </td></tr></table>	
	
<div id="addlab" style="display:none;">
<form  id="addlab_form" action=""method="post" class="layui-form" >
<div class="layui-form-item">
    <label class="layui-form-label">实验室类别：
	</label>
    <div class="layui-input-block" ><input type="text" class="layui-input" name="lab"style="width:250px">
  
	</div>
  </div>
 <div class="layui-form-item">
    <label class="layui-form-label">资源责任人：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input"name="onwer"style="width:250px"> 
	</div>
  </div>
   <div class="layui-form-item">
    <label class="layui-form-label">备注：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input"name="remark" style="width:250px"> 
	</div>
  </div>

 
</form>
</div>
<div style="display:none;" id="devedite">
<form id="deved">
<table style="width:96%;height:100%;margin-left:2%;font-size:0.9em;">
<tr>
   <td style="width:50px;">id
	</td>
    <td><input type="text" class="layui-input"name="id" id="ids"value=''style="width:250px" readonly> 	
	</td>
	<td></td>
	</tr>
<tr>
   <td style="width:50px;">实验室类别：
	</td>
    <td><input type="text" class="layui-input"name="lab" id="lab"value=''style="width:250px" readonly> 	
	</td>
	<td></td>
	</tr>
  <tr><td>设备类别：
	</td>
    <td><input type="text" class="layui-input"name="dev_sty" id="dev_sty"style="width:250px">
	</td><td></td></tr>
  <tr><td>设备型号：
	</td>
    <td><input type="text" class="layui-input"name="dev_mod" id="dev_mod"style="width:250px"> 
	</td><td></td></tr>
  <tr><td>测试项：<a onclick="addcons(this);" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe654;</i></a>
	</td>
    <td><input type="text" class="layui-input"name="content" id="content"style="width:250px"> 
	</td><td>
	<a onclick="addcon(this,event);" style="cursor:pointer;"><i class="layui-icon" style="font-size:20px;color:#2E8B57;">&#xe61f;</i>关联设备</a>
	</td></tr>
  
  <tr><td>承载量：
	</td>
    <td><input type="text" class="layui-input"name="useable" id="useable"style="width:250px"> 
	</td><td></td></tr>
  <tr><td>资源责任人：
	</td>
    <td><input type="text" class="layui-input"name="onwer" id="onwer"style="width:250px"> 
	</td><td></tr>
	<tr><td>备注：
	</td>
    <td><input type="text" class="layui-input"name="remark" id="remark"style="width:250px"> 
	</td><td></td></tr>
  </table>


</form>
</div>
</body>
<script>
function deletes(obj){
	var tr=obj.parentNode.parentNode;
	var ids=$(tr).children('td').eq(0).text();
	window.location.href="devlist.php?id="+ids;
	  		 
}

function edit(obj){
	var tr=obj.parentNode.parentNode;
	var ids=$(tr).children('td').eq(0).text();
	var lab=$(tr).children('td').eq(1).text();
	var dev=$(tr).children('td').eq(2).text();
	var mod=$(tr).children('td').eq(3).text();
	var use=$(tr).children('td').eq(4).text();
	var content=$(tr).children('td').eq(5).text();
	var onwer=$(tr).children('td').eq(6).text();
	$('#ids').val(ids);
	$('#lab').val(lab);
	$('#dev_sty').val(dev);
	$('#dev_mod').val(mod);
	$('#useable').val(use);
	$('#content').val(content);
	$('#onwer').val(onwer);
	layer.open({
			type:1,
			title:'编辑实验室',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['520px', '460px'], //宽高
			content:$("#devedite"),
			btn: ['确定', '取消']
           ,yes: function(){
			 
           
			layer.closeAll();
				
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  });
	
}
</script>
</html>