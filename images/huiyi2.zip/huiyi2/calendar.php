<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
$_search['d_id'] = $_GET['id'];
$start = $_GET['start'];
$end=$_GET['end'];
	$startdate = trim($start);//开始日期
	$enddate = trim($end);//结束日期
    $starttime=strtotime($startdate);
	$endtime=strtotime($enddate);
$sql="select
             id,
			 l_id,
			 d_id,
             title,
             starttime,
             endtime,
             lab,
			 color,
             dev_sty,
             dev_mod,
             onwer,
             user,
             remark,
             project			 
           from calendar
		   where d_id='{$_search["d_id"]}' 
		   and starttime>=$starttime and starttime<$endtime";
	$result=mysql_query($sql);
	$array = array();
	if(! $result )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
    $array[]=$row;
	
} 
echo json_encode($array,JSON_UNESCAPED_UNICODE);
//echo $starttimes;
?>