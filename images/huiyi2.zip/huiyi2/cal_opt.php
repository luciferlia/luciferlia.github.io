<?php
include_once('connect.php');//连接数据库
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>实验室预约</title>
<meta name="keywords" content="">
<meta name="description" content="">
<link href='css/fullcalendar.min.css' rel='stylesheet' />
<link href='layui/css/layui.css' rel='stylesheet' />
<script src='http://code.jquery.com/jquery-1.9.1.js'></script>
<script src='http://code.jquery.com/ui/1.10.3/jquery-ui.js'></script>
<link href='css/fullcalendar.print.min.css' rel='stylesheet' media='print' />
<script src='js/lib/moment.min.js'></script>
<script src='js/lib/jquery.min.js'></script>
<script src='layui/layui.js'></script>
<script src='js/fullcalendar.min.js'></script>
<script src='js/zh-cn.js'></script>
<script type="text/javascript" src="js/jquery.form.min.js"></script>
<style type="text/css">
#calendar{width:960px; margin:20px auto 10px auto}
.fancy{width:450px; height:auto}
.fancy h3{height:30px; line-height:30px; border-bottom:1px solid #d3d3d3; font-size:14px}
.fancy form{padding:10px}
.fancy p{height:28px; line-height:28px; padding:4px; color:#999}
.input{height:20px; line-height:20px; padding:2px; border:1px solid #d3d3d3; width:100px}
.btn{-webkit-border-radius: 3px;-moz-border-radius:3px;padding:5px 12px; cursor:pointer}
.btn_ok{background: #360;border: 1px solid #390;color:#fff}
.btn_cancel{background:#f0f0f0;border: 1px solid #d3d3d3; color:#666 }
.btn_del{background:#f90;border: 1px solid #f80; color:#fff }
.sub_btn{height:32px; line-height:32px; padding-top:6px; border-top:1px solid #f0f0f0; text-align:right; position:relative}
.sub_btn .del{position:absolute; left:2px}
</style>


<script type="text/javascript">
var form ;
	layui.use(['form', 'layedit', 'laydate'], function(){
  form = layui.form
  ,layer = layui.layer
  ,layedit = layui.layedit
  ,laydate = layui.laydate;
   form.on('select(lab)', function(data){
  labselect(data.elem);});
  form.on('select(dev)', function(data){
  devselect(data.elem);});
  //执行一个laydate实例
  laydate.render({
    elem: '#startdate' //指定元素
	 ,type: 'datetime'
  });
    laydate.render({
    elem: '#enddate' //指定元素
	 ,type: 'datetime'
  });
  form.on('select(lab)', function(data){
  labselect(data);
  console.log(data.value); //得到被选中的值
});
});


	
Date.prototype.Format=function(fmt) {         
    var o = {         
    "M+" : this.getMonth()+1, //月份         
    "d+" : this.getDate(), //日         
    "h+" : this.getHours()%12 == 0 ? 12 : this.getHours()%12, //小时         
    "H+" : this.getHours(), //小时         
    "m+" : this.getMinutes(), //分         
    "s+" : this.getSeconds(), //秒         
    "q+" : Math.floor((this.getMonth()+3)/3), //季度         
    "S" : this.getMilliseconds() //毫秒         
    };         
    var week = {         
    "0" : "/u65e5",         
    "1" : "/u4e00",         
    "2" : "/u4e8c",         
    "3" : "/u4e09",         
    "4" : "/u56db",         
    "5" : "/u4e94",         
    "6" : "/u516d"        
    };         
    if(/(y+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));         
    }         
    if(/(E+)/.test(fmt)){         
        fmt=fmt.replace(RegExp.$1, ((RegExp.$1.length>1) ? (RegExp.$1.length>2 ? "/u661f/u671f" : "/u5468") : "")+week[this.getDay()+""]);         
    }         
    for(var k in o){         
        if(new RegExp("("+ k +")").test(fmt)){         
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));         
        }         
    }         
    return fmt;         
}       
 function getLocalTime(nS) {     
        return new Date(parseInt(nS) * 1000).toString().replace(/:\d{1,2}$/,' ');       
    }
	
	
	function reset(){
		document.getElementById("ids").value="";
		document.getElementById("event").value="";
		document.getElementById("startdate").value="";
		document.getElementById("enddate").value="";
		document.getElementById("lab").value="";
		document.getElementById("dev_sty").value="";
		document.getElementById("dev_mod").value="";
		document.getElementById("onwer").value="";
		document.getElementById("user").value="";
		document.getElementById("project").value="";
		document.getElementById("remark").value="";
		
	}
$(function() {
	$('#calendar').fullCalendar({
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay,listMonth'
		},
		defaultDate: '2017-09-12',
		buttonIcons: false,
		weekNumbers: true,
		navLinks: true,
		editable: true,
        eventLimit: true, 
		events: 'json.php',

		dayClick: function(date, allDay, jsEvent, view) {
			document.getElementById("startdate").value=new Date(date).Format("yyyy-MM-dd HH:mm:ss");
			document.getElementById("enddate").value=new Date(date).Format("yyyy-MM-dd HH:mm:ss");
			document.getElementById("action").value='add';
			layer.open({
			type:1,
			title:'预定实验室',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['620px', '600px'], //宽高
			content:$("#contracText"),
			btn: ['确定', '取消']
           ,yes: function(){
			 
           $("#add_form").submit();
			layer.closeAll();
				
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  });
    	},
		eventClick:function(event){
		var ids=event.id;
		
           layer.confirm('删除还是编辑预约？', {
  btn: ['删除', '编辑', '取消'] //可以无限个按钮
  ,btn3: function(index, layero){
   layer.closeAll();
  }
}, function(index, layero){
  window.location.href='search.php?id='+ids+'&action=0';
}, function(index){
  
    $.ajax({  
             url: "search.php?id="+ids+'&action=1',    
             type: "POST",  
             dataType: 'text',
             error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
             success: function(data){//如果调用php成功   
             document.getElementById("action").value='update';
               	
               var str=JSON.parse(data);
			   var id=str.id;
			   var title=str.title;
			   var starttime=str.starttime;
			   var endtime=str.endtime;
			   var lab=str.l_id;
			   var dev_sty=str.d_id;
			   var dev_mod=str.dev_mod;
			   var onwer=str.onwer;
			   var user=str.user;
			   var project=str.project;
			   var remark=str.remark;
			   var start=getLocalTime(starttime);
			   var st=new Date(start).Format("yyyy-MM-dd HH:mm:ss");
			   var end=getLocalTime(endtime);
			   var ed=new Date(end).Format("yyyy-MM-dd HH:mm:ss");
			  
			   var sel=document.getElementById('lab');			  			  
					   $("#lab").val(lab);
					   	labselect();
					    $("#dev_sty").val(dev_sty);
                       form.render("select");					  
			  document.getElementById("ids").value=id;
			  document.getElementById("event").value=title;
			  document.getElementById("startdate").value=st;
			  document.getElementById("enddate").value=ed;
			  document.getElementById("lab").value=lab;
			  document.getElementById("dev_sty").value=dev_sty;
			  document.getElementById("dev_mod").value=dev_mod;
			  document.getElementById("onwer").value=onwer;
			  document.getElementById("user").value=user;
			  document.getElementById("project").value=project;
			  document.getElementById("remark").value=remark;
			layer.open({
			type:1,
			title:'修改预定实验室信息',
			btn:['取消','确定'],
			skin:"layui-layer-molv",
			area: ['620px', '600px'], //宽高
			content:$("#contracText"),
			btn: ['确定', '取消']
           ,yes: function(){
           
           $("#add_form").submit();
			layer.closeAll();
			reset();	
           }
           ,btn2: function(){
           layer.closeAll();
          }					
		  }); 
			 }
			 
			  });
  
  
  
});
			
		}
		
   //2		
    });
//1
});	



</script>
</head>

<body>


   <div id='calendar'></div>
<div id="contracText" style="display:none;">
<form  id="add_form" action="do.php"method="post" class="layui-form" >
 <input type="hidden" name="action" value="add" id="action">
  <input type="hidden" name="id" value="" id="ids">
<label><i class="layui-icon" style="font-size: 30px; color:#1E9FFF;;">&#xe60a;</i>  基本信息</label>
<hr class="layui-bg-green" style="width:90%;"/>
 <div class="layui-form-item">
    <label class="layui-form-label">日程内容：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input" name="event" id="event" style="width:250px" placeholder="记录你将要做的一件事..."> 
	</div>
  </div>
   <div class="layui-form-item">
    <label class="layui-form-label">实验室类别：
	</label>
    <div class="layui-input-block" style="width:250px;"><select name="lab" id="lab"lay-filter="lab" style="width:250px;" onchange="labselect(this)">
 <?php
 $query="select l_id,
	               lab,
				   onwer,
				   remark
				   from lab
				   ";
				   $res=mysql_query($query)or die('SQL错误'.mysql_error());
				   $date=array();
				   while(!!$_rows=mysql_fetch_array($res,MYSQL_ASSOC)){
			$date['l_id']=$_rows['l_id'];
            $date['lab']=$_rows['lab'];
            $date['onwer']=$_rows['onwer'];
            $date['remark']=$_rows['remark'];
 ?>
 <option value='<?php echo "{$date['l_id']}"?>'><?php echo "{$date['lab']}"?></option>
 <?php
				   }
 ?>
</select>
	</div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">设备类别：
	</label>
    <div class="layui-input-block" style="width:250px"><select  id="dev_sty" name="dev_sty" lay-filter="dev" onchange="devselect()">
	<option value="">请选择</option></select>
	</div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">设备型号：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input" id="dev_mod" name="dev_mod"style="width:250px"> 
	</div>
  </div>
  <div class="layui-form-item">
    <label class="layui-form-label">资源责任人：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input" id="onwer" name="onwer"style="width:250px"> 
	</div>
  </div>
    <div class="layui-form-item">
    <label class="layui-form-label">预订人：
	</label>
    <div class="layui-input-block"><input type="text" name="user"class="layui-input" id="user"style="width:250px" value=""> 
	</div>
  </div>
   <div class="layui-form-item">
    <label class="layui-form-label">使用项目：
	</label>
    <div class="layui-input-block"><input type="text" name="project"class="layui-input" id="project"style="width:250px" value=""> 
	</div>
  </div>
      <div class="layui-form-item">
    <label class="layui-form-label">备注：
	</label>
    <div class="layui-input-block"><input type="text"  id="remark" name="remark"class="layui-input"style="width:250px" value=""> 
	</div>
  </div>
<label><i class="layui-icon" style="font-size: 30px; color:#1E9FFF;;">&#xe637;</i>  时间选择</label>
<hr class="layui-bg-green" style="width:90%;"/>
<div class="layui-form-item">
    <label class="layui-form-label">开始时间：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input" name="startdate" id="startdate" value="" style="width:250px">
	</div>
  </div>
	<div class="layui-form-item">
    <label class="layui-form-label">结束时间：
	</label>
    <div class="layui-input-block"><input type="text" class="layui-input" name="enddate" id="enddate" value="" style="width:250px">
    </div>
  </div>
</form>
</div>

<script>


function labselect(){
var labid=$('#lab').val();//获取labid
var labperson=document.getElementById('onwer');
var dev_sty=document.getElementById("dev_sty");

$.ajax({
	url:'shows.php?id='+labid,
	type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(result){
		var str=JSON.parse(result);
	   var html='';
		for(i=0;i<str.length;i++){
			var ids=str[i].id;
			var sty=str[i].dev_sty;
			var mod=str[i].dev_mod;
			html+='<option value="'+ids+'">'+sty+'</opyion>';
			
		}
	
		dev_sty.innerHTML=html;
		form.render("select");	
	},
	error:function(errMsg){
		alert("加载失败");
	}
	
	
});

if(labid==2||labid==3||labid==4||labid==5||labid==6||labid==7||labid==9)
{
labperson.value='马金丽';
}else if(labid==1)
{
labperson.value='陈亚东(上海) 王维(深圳)';
}else if(labid==20)
{
labperson.value='魏巍';
}else if(labid==8){
labperson.value='陈亚东';
}else{
labperson.value='何婵娇';
}

}


function devselect(){
var devid=$('#dev_sty').val();

var labid=$('#lab').val();//获取labid
var dev_sty=document.getElementById("dev_mod");
var temp;
$.ajax({
	url:'shows.php?id='+labid,
	type:"POST",
	dataType: 'text',
    error: function(errMsg){    
                 alert('Error loading XML document'); 
                console.log(errMsg);				 
             },    
	success:function(result){
		var str=JSON.parse(result);
	  
		for(i=0;i<str.length;i++){
			var ids=str[i].id;
			
			var mod=str[i].dev_mod;
			if(devid==ids){
				dev_sty.value=mod;
			}
			
		}
	
	},
	error:function(errMsg){
		alert("加载失败");
	}
	
	
});

}


</script>



</body>
</html>
