/*
SQLyog v10.2 
MySQL - 5.7.17-log : Database - calender
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`calender` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `calender`;

/*Table structure for table `calendar` */

DROP TABLE IF EXISTS `calendar`;

CREATE TABLE `calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `starttime` int(40) NOT NULL,
  `endtime` int(40) DEFAULT NULL,
  `allday` tinyint(1) NOT NULL DEFAULT '0',
  `color` varchar(20) DEFAULT NULL,
  `lab` varchar(40) DEFAULT NULL,
  `dev_sty` varchar(40) DEFAULT NULL,
  `dev_mod` varchar(40) DEFAULT NULL,
  `onwer` varchar(40) DEFAULT NULL,
  `user` varchar(40) DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `project` varchar(40) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `l_id` int(20) DEFAULT NULL,
  `d_id` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `l_id` (`l_id`),
  KEY `d_id` (`d_id`),
  CONSTRAINT `calendar_ibfk_1` FOREIGN KEY (`l_id`) REFERENCES `lab` (`l_id`),
  CONSTRAINT `calendar_ibfk_2` FOREIGN KEY (`d_id`) REFERENCES `dev` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

/*Data for the table `calendar` */

insert  into `calendar`(`id`,`title`,`starttime`,`endtime`,`allday`,`color`,`lab`,`dev_sty`,`dev_mod`,`onwer`,`user`,`remark`,`project`,`status`,`l_id`,`d_id`) values (1,'信息化系统会议',1504713600,1504713600,1,'#360','Audio Lab','HEAD Acoustics测试系统','','','','','ALC-A155-K003','结束',2,4),(2,'学习',1504800000,1504800000,1,'#FFFACD','OTA Lab','ETS OTA测试系统','','','','','	AUS-E262X-K000','结束',1,1),(3,'会议1111',1504749600,1504749600,0,'#A4D3EE','Mechanical Lab','软压试验机#1','','','','','	AUS-E296-K000','结束',14,55),(12,'我的测试',1505523600,1505523600,0,'	#FFE4E1','Mechanical Lab','软压试验机#1','','','','','undefined','结束',14,55),(15,'remark all',1506038400,1506038400,0,'	#FFDAB9','Audio Lab','HEAD Acoustics测试系统','半消声室（科奥克）','马金丽','廖迁','remark','BLU-V303X-K020N','结束',2,4),(16,'实验室雨夜',1505350800,1505386800,0,'#360','ESD Lab','静电枪#1','234','马金丽','廖迁','1111','	FIH-E400-U000','结束',3,6),(28,'ceshi',1505433600,1505444400,0,'#E6E6FA','Thermal Testing Lab','温升系统#1','2','马金丽','3','5','GIG-E628F-K100','结束',4,8),(29,'动态form  action',1505952000,1505962800,0,'#f30','Audio Lab','听音室','45','马金丽','7677','6756','	MMX-E527X-K000','正常',2,5),(30,'修改',1505865600,1505872800,0,'#00BFFF','Audio Lab','HEAD Acoustics测试系统','212','马金丽','','','BLU-V303X-K000','结束',2,4),(31,'预定实验室测试(～￣▽￣)～',1505955600,1505977200,0,'#79CDCD','ESD Lab','静电枪#1','dito','马金丽','廖迁','','U10','正常',3,6),(33,'测试时间是几位的',1506441600,1506524400,0,'	#458B74','Thermal Testing Lab','温升系统#1','FLIR A310','马金丽','廖迁','','U10','正常',4,8),(34,'看看时间',1506445200,1506470400,0,'	#00FFFF','ESD Lab','静电枪#1','dito','马金丽','廖迁','','U10','正常',3,6),(35,'测试',1506560400,1506567600,0,'#06c','射频实验室 RF Testing Lab','RF测试站#1','3G','陈亚东','liaoqian','u10','','正常',8,15),(36,'ceshi2',1506574800,1506592800,0,'#00868B','射频实验室 RF Testing Lab','RF测试站#3','3G','陈亚东','liaoqian','','A153','正常',8,17),(37,'ceshi外键',1504569600,1504580400,0,'	#32CD32','Audio Lab','HEAD Acoustics测试系统','平板全消声室（科奥克）','马金丽','廖迁','','GIG','正常',2,4),(38,'哈哈哈',1505196000,1505224800,0,'	#B3EE3A','ESD Lab','静电枪#1','dito','马金丽','廖迁','','想','正常',3,6),(39,'shijiancuo',1505260800,1505271600,0,'#FFFF00','Audio Lab','听音室','半消声室（科奥克）','马金丽','','','','正常',2,5),(40,'测试跨天的数',1505779200,1505962800,0,'	#FFFF00','射频实验室 RF Testing Lab','RF测试站#2','(2G/3G/4G)','陈亚东','廖迁','','D625','正常',8,16),(41,'测试只跨一天的',1506384000,1506470400,0,'#C1FFC1','Audio Lab','HEAD Acoustics测试系统','平板全消声室（科奥克）','马金丽','liaoqian','','D625','正常',2,4),(42,'重复',1506556800,1506564000,0,'#FF69B4',NULL,NULL,'(2G/3G/4G)','陈亚东','廖迁','','D625','正常',8,15),(43,'跨天',1505865600,1506211200,0,'#360','1','1','AMS8923-150AMS8923-150','陈亚东(上海) 王维(深圳)','112','','','正常',1,1);

/*Table structure for table `dev` */

DROP TABLE IF EXISTS `dev`;

CREATE TABLE `dev` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab` varchar(40) DEFAULT NULL,
  `dev_sty` varchar(40) DEFAULT NULL,
  `dev_mod` varchar(40) DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `useable` varchar(40) DEFAULT NULL,
  `l_id` int(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `l_id` (`l_id`),
  CONSTRAINT `dev_ibfk_1` FOREIGN KEY (`l_id`) REFERENCES `lab` (`l_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

/*Data for the table `dev` */

insert  into `dev`(`id`,`lab`,`dev_sty`,`dev_mod`,`remark`,`useable`,`l_id`) values (1,'天线实验室 OTA Lab','ETS OTA测试系统','AMS8923-150AMS8923-150',NULL,NULL,1),(2,'天线实验室 OTA Lab','广屏 OTA测试系统','广屏（自由空间）',NULL,NULL,1),(3,'天线实验室 OTA Lab','GTS OTA测试系统','RayZone 1800',NULL,NULL,1),(4,'音频实验室 Audio Lab','HEAD Acoustics测试系统','平板全消声室（科奥克）',NULL,NULL,2),(5,'音频实验室 Audio Lab','听音室','半消声室（科奥克）',NULL,NULL,2),(6,'静电实验室 ESD Lab','静电枪#1','dito',NULL,NULL,3),(7,'静电实验室 ESD Lab','静电枪#2','普瑞玛',NULL,NULL,3),(8,'温升实验室 Thermal Testing Lab','温升系统#1','FLIR A310',NULL,NULL,4),(9,'温升实验室 Thermal Testing Lab','温升系统#2','待规划',NULL,NULL,4),(10,'充放电实验室 Charge-Discharge Lab','充放电测试系统','Agilent34970A ESPEC SU-242',NULL,NULL,5),(11,'TP实验室 TP  Performance Testing Lab','汇顶TP测试机台','GT168',NULL,NULL,6),(12,'TP实验室 TP  Performance Testing Lab','待规划','待规划',NULL,NULL,6),(13,'基带实验室 Baseband Testing Lab','功耗测试站#1','待规划',NULL,NULL,7),(14,'基带实验室 Baseband Testing Lab','功耗测试站#2','待规划',NULL,NULL,7),(15,'射频实验室 RF Testing Lab','RF测试站#1','(2G/3G/4G)',NULL,NULL,8),(16,'射频实验室 RF Testing Lab','RF测试站#2','(2G/3G/4G)',NULL,NULL,8),(17,'射频实验室 RF Testing Lab','RF测试站#3','(2G/3G/4G)',NULL,NULL,8),(18,'射频实验室 RF Testing Lab','RF测试站#4','(2G/3G/4G)',NULL,NULL,8),(19,'射频实验室 RF Testing Lab','RF测试站#5','(2G/3G/4G)',NULL,NULL,8),(20,'射频实验室 RF Testing Lab','RF测试站#6','(2G/3G/4G)',NULL,NULL,8),(21,'射频实验室 RF Testing Lab','RF测试站#7','(2G/3G/4G)',NULL,NULL,8),(22,'射频实验室 RF Testing Lab','RF测试站#8','(2G/3G/4G)',NULL,NULL,8),(23,'射频实验室 RF Testing Lab','GPS测试站#1',NULL,NULL,NULL,8),(24,'射频实验室 RF Testing Lab','BT测试站',NULL,NULL,NULL,8),(25,'光学实验室 Optical Performance Testing Lab','Camera客观测试站#1','1）SPL QC 多色温灯箱 2）CL-200A 色彩照度计 3）45度补光灯 ',NULL,NULL,9),(26,'光学实验室 Optical Performance Testing Lab','Camera客观测试站#2','1）SPL QC 多色温灯箱 2）CL-200A 色彩照度计 3）45度补光灯 ',NULL,NULL,9),(27,'光学实验室 Optical Performance Testing Lab','Camera客观测试站#3','1）SPL QC 多色温灯箱 2）CL-200A 色彩照度计 3）45度补光灯 ',NULL,NULL,9),(28,'光学实验室 Optical Performance Testing Lab','Camera主观测试站','1）ETC-lightSTUDIO-L IQ-LED静态实景测试灯箱 2）EX1',NULL,NULL,9),(29,'光学实验室 Optical Performance Testing Lab','LCM客观测试站','1）CS-200 亮度计 2)CA310+PS32色彩照度计',NULL,NULL,9),(30,'光学实验室 Optical Performance Testing Lab','Flash客观测试区','闪光灯测试仪（RT-SGD9） 闪光灯测试图卡 （RT-SGDC3）',NULL,NULL,9),(31,'盐雾实验室 Salt Spray Lab','盐水喷雾试验箱','铁木真 （TMJ-9701B）',NULL,NULL,10),(32,'环境实验室 Environmental Lab','恒温恒湿箱#1','庆声 (KTHE-415TBS) （ -45℃+150℃） （10%～98%r.',NULL,NULL,11),(33,'环境实验室 Environmental Lab','恒温恒湿箱#2','庆声 (KTHE-415TBS) （ -45℃+150℃） （10%～98%r.',NULL,NULL,11),(34,'环境实验室 Environmental Lab','恒温恒湿箱#3','ESPEC (GPL-2) （ -40℃+180℃） （10%～98%r.h）',NULL,NULL,11),(35,'环境实验室 Environmental Lab','恒温恒湿箱#4','拓米洛 (TOH-165FX) （ -40℃+150℃）（10%～98%r.h）',NULL,NULL,11),(36,'环境实验室 Environmental Lab','恒温恒湿箱#5','奥斯韦特 （GDW/SJ-0150） （ -40℃+150℃） （20%～98%',NULL,NULL,11),(37,'环境实验室 Environmental Lab','恒温恒湿箱#6','奥斯韦特 （GDW/SJ-0150） （ -40℃+150℃） （20%～98%',NULL,NULL,11),(38,'环境实验室 Environmental Lab','恒温恒湿箱#7','奥斯韦特 （GDW/SJ-0150） （ -40℃+150℃） （20%～98%',NULL,NULL,11),(39,'环境实验室 Environmental Lab','恒温恒湿箱#8','奥斯韦特 （GDW/SJ-0150） （ -40℃+150℃） （20%～98%',NULL,NULL,11),(40,'环境实验室 Environmental Lab','恒温恒湿箱#9','待规划',NULL,NULL,11),(41,'环境实验室 Environmental Lab','恒温恒湿箱#10','待规划',NULL,NULL,11),(42,'环境实验室 Environmental Lab','恒温恒湿箱#11','待规划',NULL,NULL,11),(43,'环境实验室 Environmental Lab','恒温恒湿箱#12','待规划',NULL,NULL,11),(44,'环境实验室 Environmental Lab','温度冲击箱#1','奥斯韦特 （TSA-A-0100） （ -45℃+120℃）',NULL,NULL,11),(45,'环境实验室 Environmental Lab','温度冲击箱#2','奥斯韦特 （TSA-A-0100） （ -45℃+120℃）',NULL,NULL,11),(46,'环境实验室 Environmental Lab','温度冲击箱#3','待规划',NULL,NULL,11),(47,'环境实验室 Environmental Lab','紫外光照箱','QLAB (QUV/se)',NULL,NULL,11),(48,'ALT实验室 ALT Lab','快速温变箱','Thermotron',NULL,NULL,12),(49,'防水实验室 Waterproof Lab','淋雨试验机','沃华 WH-3601 （IPX1-IPX4)',NULL,NULL,13),(50,'机械实验室 Mechanical Lab','按键寿命试验机#1','沃华 WH-1601-4',NULL,NULL,14),(51,'机械实验室 Mechanical Lab','按键寿命试验机#2','沃华 WH-1601-4',NULL,NULL,14),(52,'机械实验室 Mechanical Lab','桌面跌落试验机#1','高品 GP-2113-2',NULL,NULL,14),(53,'机械实验室 Mechanical Lab','桌面跌落试验机#2','沃华 WH-2108-2',NULL,NULL,14),(54,'机械实验室 Mechanical Lab','桌面跌落试验机#3','沃华 WH-2108-4D',NULL,NULL,14),(55,'机械实验室 Mechanical Lab','软压试验机#1','高品 GP-2110',NULL,NULL,14),(56,'机械实验室 Mechanical Lab','软压试验机#2','沃华 WH-1502M',NULL,NULL,14),(57,'机械实验室 Mechanical Lab','扭曲试验机#1','高品 GP-2107',NULL,NULL,14),(58,'机械实验室 Mechanical Lab','扭曲试验机#2','高品 GP-2107',NULL,NULL,14),(59,'机械实验室 Mechanical Lab','接口插拔试验机#1','高品 GP-2105-B',NULL,NULL,14),(60,'机械实验室 Mechanical Lab','接口插拔试验机#2','高品 GP-2105-B',NULL,NULL,14),(61,'机械实验室 Mechanical Lab','接口插拔试验机#3','高品 GP-2105-B',NULL,NULL,14),(62,'机械实验室 Mechanical Lab','摩擦寿命试验机#1','高品 GP-2109B',NULL,NULL,14),(63,'机械实验室 Mechanical Lab','摩擦寿命试验机#2','沃华 WH-2509',NULL,NULL,14),(64,'机械实验室 Mechanical Lab','纸带耐磨试验机#1','高品 GP-RCA-7-IBB',NULL,NULL,14),(65,'机械实验室 Mechanical Lab','纸带耐磨试验机#2','高品 GP-RCA-7-IBB',NULL,NULL,14),(66,'机械实验室 Mechanical Lab','弹簧锤','高品 GP-TLJ',NULL,NULL,14),(67,'力分析实验室 Force analy Lab','全自动综合测力试验机#1','高品 GP-IW2000',NULL,NULL,0),(68,'力分析实验室 Force analy Lab','全自动综合测力试验机#2','沃华 WH-1207-S',NULL,NULL,0),(69,'力分析实验室 Force analy Lab','全自动综合测力试验机#3','沃华 WH-1207-2',NULL,NULL,0),(70,'力分析实验室 Force analy Lab','全自动综合测力试验机#4','沃华 WH-1207-2',NULL,NULL,0),(71,'力分析实验室 Force analy Lab','三轴全自动荷重试验机','沃华 WH-1207-XY',NULL,NULL,0),(72,'力分析实验室 Force analy Lab','指针式推拉力计#1','爱森堡 HLD',NULL,NULL,0),(73,'力分析实验室 Force analy Lab','指针式推拉力计#2','爱森堡 HLD',NULL,NULL,0),(74,'力分析实验室 Force analy Lab','指针式推拉力计#3','爱森堡 HLD',NULL,NULL,0),(75,'砂尘实验室 Dust Lab','砂尘试验箱','奥斯韦特 IPS-0500',NULL,NULL,16),(76,'跌落实验室 Free drop Lab','定向跌落仪#1','沃华 WH-2101',NULL,NULL,17),(77,'跌落实验室 Free drop Lab','定向跌落仪#2','沃华 WH06-2101',NULL,NULL,17),(78,'跌落实验室 Free drop Lab','滚筒跌落#1','高品 GP-2115',NULL,NULL,17),(79,'跌落实验室 Free drop Lab','滚筒跌落#2','沃华 WH06-2105-23BD',NULL,NULL,17),(80,'包装实验室 Pakage Lab','包装跌落试验机','待规划',NULL,NULL,18),(81,'振动实验室 Vibration Lab','电动振动试验系统','航天希尔 MPA403/M124M/  HE600SQM',NULL,NULL,19),(82,'电池实验室 Battery Lab','电池充放电柜','新威尔',NULL,NULL,20),(83,'电池实验室 Battery Lab','电池挤压试验机','贝尔 （BE-8101）',NULL,NULL,20),(84,'电池实验室 Battery Lab','温控型电池短路试验机','贝尔 （BE-8102）',NULL,NULL,20),(85,'电池实验室 Battery Lab','热滥用试验机','贝尔 （BE-8103）',NULL,NULL,20),(86,'电池实验室 Battery Lab','重物冲击试验机','贝尔 （BE-8106）',NULL,NULL,20),(87,'器部件实验室','三坐标全自动影像仪','台湾万濠 （VMS-3020H）',NULL,NULL,21),(88,'器部件实验室','电机综合测试仪 （马达寿命）','GC-0618-LH',NULL,NULL,21);

/*Table structure for table `lab` */

DROP TABLE IF EXISTS `lab`;

CREATE TABLE `lab` (
  `l_id` int(10) NOT NULL,
  `lab` varchar(40) DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `onwer` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`l_id`),
  KEY `l_id` (`onwer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `lab` */

insert  into `lab`(`l_id`,`lab`,`remark`,`onwer`) values (0,'力分析实验室 Force analy Lab',NULL,NULL),(1,'天线实验室 OTA Lab',NULL,'马金丽'),(2,'音频实验室 Audio Lab',NULL,'马金丽'),(3,'静电实验室 ESD Lab',NULL,'马金丽'),(4,'温升实验室 Thermal Testing Lab',NULL,'马金丽'),(5,'充放电实验室 Charge-Discharge Lab',NULL,'马金丽'),(6,'TP实验室 TP  Performance Testing Lab',NULL,'马金丽'),(7,'基带实验室 Baseband Testing Lab',NULL,'马金丽'),(8,'射频实验室 RF Testing Lab',NULL,'陈亚东'),(9,'光学实验室 Optical Performance Testing Lab',NULL,'马金丽'),(10,'盐雾实验室 Salt Spray Lab',NULL,'何婵姣'),(11,'环境实验室 Environmental Lab',NULL,'何婵姣'),(12,'ALT实验室 ALT Lab',NULL,'何婵姣'),(13,'防水实验室 Waterproof Lab',NULL,'何婵姣'),(14,'机械实验室 Mechanical Lab',NULL,'何婵姣'),(16,'砂尘实验室 Dust Lab',NULL,NULL),(17,'跌落实验室 Free drop Lab',NULL,NULL),(18,'包装实验室 Pakage Lab',NULL,NULL),(19,'振动实验室 Vibration Lab',NULL,NULL),(20,'电池实验室 Battery Lab',NULL,'魏巍'),(21,'器部件实验室',NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
