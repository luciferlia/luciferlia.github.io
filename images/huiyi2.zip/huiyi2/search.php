<?php
include_once('connect.php');//连接数据库
header('Content-Type:text/html;charset=utf-8'); 
$_search['id'] = $_GET['id'];
$action=$_GET['action']; 
   if($action==1){  
    
       $sql = "SELECT 
	   id,
       title,
	   starttime,
	   endtime,
	   l_id,
	   d_id,
	   dev_mod,
	   onwer,
	   user,
	   project,
	   remark
	   FROM calendar where id={$_search['id']}";
$result = mysql_query($sql);
if(! $result )
{
  die('Could not get data: ' . mysql_error());
}
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
    echo json_encode($row,JSON_UNESCAPED_UNICODE);
} 

  } 
else{
	mysql_query("DELETE FROM calendar WHERE id={$_search['id']}")or die('SQL错误'.mysql_error());
Header("HTTP/1.1 303 See Other"); 
Header("Location: cal_opt.php"); 
exit; //from www.w3sky.com 
	
}  
   

?>