/**
 * 
 */var arr = tree.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type = 'checkbox'){
input.onclick = ClickInput
}
}
function ClickInput(){
var li = this.parentElement;
var arr = li.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type == 'checkbox'){
input.checked = this.checked
}
}
var li = li.parentElement.parentElement
while(li.tagName.toLowerCase() == 'li'){
var input = li.childNodes[0]
if(input.tagName.toLowerCase() == 'input'){
input.checked = this.checked
}
li = li.parentElement.parentElement
}
}

var arr = tree1.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type = 'checkbox'){
input.onclick = ClickInput
}
}
function ClickInput(){
var li = this.parentElement;
var arr = li.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type == 'checkbox'){
input.checked = this.checked
}
}
var li = li.parentElement.parentElement
while(li.tagName.toLowerCase() == 'li'){
var input = li.childNodes[0]
if(input.tagName.toLowerCase() == 'input'){
input.checked = this.checked
}
li = li.parentElement.parentElement
}
}

var arr = tree2.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type = 'checkbox'){
input.onclick = ClickInput
}
}
function ClickInput(){
var li = this.parentElement;
var arr = li.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type == 'checkbox'){
input.checked = this.checked
}
}
var li = li.parentElement.parentElement
while(li.tagName.toLowerCase() == 'li'){
var input = li.childNodes[0]
if(input.tagName.toLowerCase() == 'input'){
input.checked = this.checked
}
li = li.parentElement.parentElement
}
}

var arr = tree3.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type = 'checkbox'){
input.onclick = ClickInput
}
}
function ClickInput(){
var li = this.parentElement;
var arr = li.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type == 'checkbox'){
input.checked = this.checked
}
}
var li = li.parentElement.parentElement
while(li.tagName.toLowerCase() == 'li'){
var input = li.childNodes[0]
if(input.tagName.toLowerCase() == 'input'){
input.checked = this.checked
}
li = li.parentElement.parentElement
}
}

var arr = tree4.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type = 'checkbox'){
input.onclick = ClickInput
}
}
function ClickInput(){
var li = this.parentElement;
var arr = li.getElementsByTagName('input')
for(var i=0; i < arr.length; i++){
var input = arr[i]
if(input.type == 'checkbox'){
input.checked = this.checked
}
}
var li = li.parentElement.parentElement
while(li.tagName.toLowerCase() == 'li'){
var input = li.childNodes[0]
if(input.tagName.toLowerCase() == 'input'){
input.checked = this.checked
}
li = li.parentElement.parentElement
}
}