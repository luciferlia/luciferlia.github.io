
	function exportPolicy(policypoolId){
	 layer.confirm('确定导出策略模板?', {icon: 3, title:'提示'}, function(index){
 layer.close(index);
$.ajax({
			type:'post',
			url:'exportPolicy?policypoolId='+policypoolId,
			success:function(data){
			
				if(data=='success'){

					window.location.href = "policy_downloadPolicy";
				}else{
					layer.msg('导出策略失败,该模板中沒有策略',{time:2000});
					window.location.reload();	
				}
			}
		});

},function(index){ layer.close(index);});
		
	}
	function importpolicy(policypoolId){
		
	}
	
  
  
	
	
	function checkDate(obj){
	var date1=obj.value;
	
		var tr=obj.parentNode.parentNode;


var strat=$(tr).children('td').eq(10)[0].children[0];
var date2=strat.value;
var day1=date1.replace(/\-/gi,"/");
var day2=date2.replace(/\-/gi,"/");
var time1=new Date(day1).getTime();
var time2=new Date(day2).getTime();
if(time1<time2)
{
obj.value="";
layer.msg("结束时间不能小于起始时间");

}else{
return true;
}		   

	}
		
	

			