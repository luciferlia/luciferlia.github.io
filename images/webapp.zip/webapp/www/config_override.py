#config_override.py
# -*- coding: utf-8 -*-
#部署到服务器时，通常需要修改数据库的host等信息
#把config_default.py作为开发环境的标准配置，把config_override.py作为生产环境的标准配置
#我们就可以既方便地在本地开发，又可以随时把应用部署到服务器上
'''
Override configurations.
'''

configs={
    'db':{
        'host':'127.0.0.1'       
        }
    }
